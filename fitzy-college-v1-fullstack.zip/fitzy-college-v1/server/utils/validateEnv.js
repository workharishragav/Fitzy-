const REQUIRED_ENV_VARS = ['PORT', 'MONGO_URI', 'JWT_SECRET', 'GEMINI_API_KEY'];

/**
 * Fails fast with a clear message if a required environment variable is
 * missing, instead of letting the server start and fail confusingly later
 * (e.g. a cryptic jwt.sign error, or every Gemini call silently rejecting).
 */
const validateEnv = () => {
  const missing = REQUIRED_ENV_VARS.filter((key) => !process.env[key]);

  if (missing.length > 0) {
    console.error(`Missing required environment variable(s): ${missing.join(', ')}`);
    console.error('Copy .env.example to .env and fill in real values.');
    process.exit(1);
  }
};

module.exports = validateEnv;
