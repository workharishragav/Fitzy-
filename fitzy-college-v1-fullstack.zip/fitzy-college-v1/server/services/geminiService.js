const https = require('https');

// Not a secret — just which Gemini model to call. The key itself always
// comes from process.env.GEMINI_API_KEY, never hardcoded.
const GEMINI_MODEL = 'gemini-1.5-flash';
const GEMINI_API_HOST = 'generativelanguage.googleapis.com';

/**
 * Low-level call to the Google Gemini generateContent endpoint.
 *
 * This is the ONLY place in the codebase that talks to Gemini directly —
 * routes and controllers must never call it themselves (per the required
 * Route -> Controller -> Gemini Service -> Google Gemini API architecture).
 *
 * Takes a fully-constructed prompt string, returns the model's raw text
 * response. Feature-specific prompt construction (workout recommendations,
 * fitness insights) lives in separate exported functions added to this
 * same service, which call this helper — not in the routes/controllers.
 *
 * Always rejects with a generic Error (never the raw Gemini/network error),
 * so a controller catching it can safely pass a message to the client
 * without leaking internal details or the API key.
 */
const callGemini = (prompt) => {
  return new Promise((resolve, reject) => {
    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) {
      // Server misconfiguration — not something to describe to the client.
      return reject(new Error('AI service is not configured'));
    }

    const payload = JSON.stringify({
      contents: [
        {
          parts: [{ text: prompt }]
        }
      ]
    });

    const options = {
      hostname: GEMINI_API_HOST,
      path: `/v1beta/models/${GEMINI_MODEL}:generateContent?key=${apiKey}`,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload)
      }
    };

    const req = https.request(options, (res) => {
      let raw = '';
      res.on('data', (chunk) => {
        raw += chunk;
      });

      res.on('end', () => {
        let parsed;
        try {
          parsed = JSON.parse(raw);
        } catch (parseError) {
          return reject(new Error('AI service returned an unreadable response'));
        }

        if (res.statusCode < 200 || res.statusCode >= 300) {
          // Log the real reason server-side; never forward it to the client.
          console.error('Gemini API error:', res.statusCode, parsed?.error?.message);
          return reject(new Error('AI service request failed'));
        }

        const text = parsed?.candidates?.[0]?.content?.parts?.[0]?.text;
        if (!text) {
          return reject(new Error('AI service returned no usable content'));
        }

        resolve(text);
      });
    });

    req.on('error', (error) => {
      console.error('Gemini request network error:', error.message);
      reject(new Error('Failed to reach the AI service'));
    });

    req.write(payload);
    req.end();
  });
};

/**
 * Gemini sometimes wraps JSON responses in markdown code fences even when
 * told not to — strip those before parsing. Throws a generic Error (safe
 * to bubble up to the client) if the result still isn't valid JSON.
 */
const parseJsonResponse = (rawText) => {
  const cleaned = rawText.replace(/```json\s*|```/g, '').trim();
  try {
    return JSON.parse(cleaned);
  } catch (error) {
    throw new Error('AI service returned an unexpected response format');
  }
};

const buildRecommendationPrompt = ({ age, fitnessGoal, experienceLevel }) => `
You are a certified fitness coaching assistant inside a workout-tracking app called Fitzy.
Generate a personalized workout recommendation for a user with:
- Age: ${age}
- Fitness goal: ${fitnessGoal}
- Experience level: ${experienceLevel}

Respond with ONLY valid JSON (no markdown formatting, no code fences, no extra commentary) matching exactly this structure:

{
  "workoutPlan": {
    "overview": "string - a short summary of the overall plan",
    "focusAreas": ["string", "string"]
  },
  "weeklySchedule": [
    {
      "day": "string - e.g. Monday",
      "focus": "string - e.g. Upper Body Strength",
      "exercises": [
        { "name": "string", "sets": "string", "reps": "string", "notes": "string" }
      ]
    }
  ],
  "trainingGuidance": "string - general training tips suited to this experience level",
  "motivationalGuidance": "string - a short motivational message",
  "safetyRecommendations": ["string", "string"],
  "disclaimer": "string - a brief note that this is general fitness guidance, not medical advice, and to consult a healthcare professional before starting any new exercise program"
}

Keep the weekly schedule realistic for the stated experience level (fewer,
simpler days for Beginner; more volume and complexity for Advanced). Return
valid JSON only — no prose before or after it.
`.trim();

/**
 * Builds the recommendation prompt, calls Gemini, and returns the parsed
 * structured recommendation. Callers (controllers) get either a resolved
 * object or a generic Error — never a raw Gemini/network failure.
 */
const getWorkoutRecommendation = async ({ age, fitnessGoal, experienceLevel }) => {
  const prompt = buildRecommendationPrompt({ age, fitnessGoal, experienceLevel });
  const rawText = await callGemini(prompt);
  return parseJsonResponse(rawText);
};

const buildInsightsPrompt = ({ totalWorkouts, averageWorkoutDuration, totalCaloriesBurned }) => `
You are a certified fitness coaching assistant inside a workout-tracking app called Fitzy.
Analyze this user's workout activity so far:
- Total workouts logged: ${totalWorkouts}
- Average workout duration (minutes): ${averageWorkoutDuration}
- Total calories burned: ${totalCaloriesBurned}

Respond with ONLY valid JSON (no markdown formatting, no code fences, no extra commentary) matching exactly this structure:

{
  "performanceAnalysis": "string - an analysis of their activity level and consistency based on the numbers given",
  "improvementSuggestions": ["string", "string"],
  "motivationalAdvice": "string - a short motivational message",
  "progressSummary": "string - a brief summary of their overall fitness progress",
  "disclaimer": "string - a brief note that this is general fitness guidance, not medical advice, and to consult a healthcare professional for any health concerns"
}

Return valid JSON only — no prose before or after it.
`.trim();

/**
 * Builds the insights prompt, calls Gemini, and returns the parsed
 * structured insights. Same contract as getWorkoutRecommendation: resolves
 * with an object, or throws a generic (safe) Error.
 */
const getFitnessInsights = async ({ totalWorkouts, averageWorkoutDuration, totalCaloriesBurned }) => {
  const prompt = buildInsightsPrompt({ totalWorkouts, averageWorkoutDuration, totalCaloriesBurned });
  const rawText = await callGemini(prompt);
  return parseJsonResponse(rawText);
};

module.exports = { callGemini, getWorkoutRecommendation, getFitnessInsights };
