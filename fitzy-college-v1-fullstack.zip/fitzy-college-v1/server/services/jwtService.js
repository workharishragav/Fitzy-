const jwt = require('jsonwebtoken');

/**
 * Signs a JWT for the given payload (typically { id: user._id }).
 */
const generateToken = (payload) => {
  return jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '7d' });
};

/**
 * Verifies a JWT and returns its decoded payload.
 * Throws if the token is invalid or expired — callers (e.g. the auth
 * middleware in Phase 6) are responsible for catching that.
 */
const verifyToken = (token) => {
  return jwt.verify(token, process.env.JWT_SECRET);
};

module.exports = { generateToken, verifyToken };
