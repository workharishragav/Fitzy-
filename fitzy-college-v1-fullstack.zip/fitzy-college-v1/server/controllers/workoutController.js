const mongoose = require('mongoose');
const Workout = require('../models/Workout');

/**
 * Ownership check: is this workout owned by the requesting user?
 * Returning 403 (rather than a silent 404) here is a deliberate choice for
 * this college project — it makes the "cross-user access" test case
 * (section 19) unambiguous to verify in Postman.
 */
const isOwner = (workout, userId) => workout.user.toString() === userId.toString();

/**
 * Escapes regex special characters so user-supplied search/category text
 * is always treated as a literal substring, never as a regex pattern.
 */
const escapeRegex = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// POST /api/workouts
const createWorkout = async (req, res, next) => {
  try {
    const { workoutName, category, duration, caloriesBurned, workoutDate } = req.body;

    const workout = await Workout.create({
      user: req.user._id,
      workoutName,
      category,
      duration,
      caloriesBurned,
      workoutDate
    });

    return res.status(201).json({
      success: true,
      message: 'Workout created successfully',
      data: { workout }
    });
  } catch (error) {
    next(error);
  }
};

// GET /api/workouts
// Supports optional query params, combinable: ?search=running&category=cardio&date=2026-09-15
const getWorkouts = async (req, res, next) => {
  try {
    const { search, category, date } = req.query;
    const filter = { user: req.user._id };

    if (search) {
      // Partial, case-insensitive match on workout name.
      filter.workoutName = { $regex: escapeRegex(search), $options: 'i' };
    }

    if (category) {
      // Case-insensitive exact match (schema stores category capitalized,
      // e.g. "Cardio", but the spec's example uses lowercase "cardio").
      filter.category = { $regex: `^${escapeRegex(category)}$`, $options: 'i' };
    }

    if (date) {
      const parsedDate = new Date(date);
      if (Number.isNaN(parsedDate.getTime())) {
        return res.status(400).json({
          success: false,
          message: 'Invalid date format. Use YYYY-MM-DD.'
        });
      }

      // Match any workout that falls within that calendar day.
      const startOfDay = new Date(parsedDate);
      startOfDay.setUTCHours(0, 0, 0, 0);
      const endOfDay = new Date(parsedDate);
      endOfDay.setUTCHours(23, 59, 59, 999);
      filter.workoutDate = { $gte: startOfDay, $lte: endOfDay };
    }

    const workouts = await Workout.find(filter).sort({ workoutDate: -1 });

    return res.status(200).json({
      success: true,
      message: 'Workouts retrieved successfully',
      data: { count: workouts.length, workouts }
    });
  } catch (error) {
    next(error);
  }
};

// GET /api/workouts/:id
const getWorkoutById = async (req, res, next) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid workout ID'
      });
    }

    const workout = await Workout.findById(id);

    if (!workout) {
      return res.status(404).json({
        success: false,
        message: 'Workout not found'
      });
    }

    if (!isOwner(workout, req.user._id)) {
      return res.status(403).json({
        success: false,
        message: 'You are not authorized to access this workout'
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Workout retrieved successfully',
      data: { workout }
    });
  } catch (error) {
    next(error);
  }
};

// PUT /api/workouts/:id
const updateWorkout = async (req, res, next) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid workout ID'
      });
    }

    const workout = await Workout.findById(id);

    if (!workout) {
      return res.status(404).json({
        success: false,
        message: 'Workout not found'
      });
    }

    if (!isOwner(workout, req.user._id)) {
      return res.status(403).json({
        success: false,
        message: 'You are not authorized to update this workout'
      });
    }

    const { workoutName, category, duration, caloriesBurned, workoutDate } = req.body;

    if (workoutName !== undefined) workout.workoutName = workoutName;
    if (category !== undefined) workout.category = category;
    if (duration !== undefined) workout.duration = duration;
    if (caloriesBurned !== undefined) workout.caloriesBurned = caloriesBurned;
    if (workoutDate !== undefined) workout.workoutDate = workoutDate;

    const updatedWorkout = await workout.save();

    return res.status(200).json({
      success: true,
      message: 'Workout updated successfully',
      data: { workout: updatedWorkout }
    });
  } catch (error) {
    next(error);
  }
};

// DELETE /api/workouts/:id
const deleteWorkout = async (req, res, next) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid workout ID'
      });
    }

    const workout = await Workout.findById(id);

    if (!workout) {
      return res.status(404).json({
        success: false,
        message: 'Workout not found'
      });
    }

    if (!isOwner(workout, req.user._id)) {
      return res.status(403).json({
        success: false,
        message: 'You are not authorized to delete this workout'
      });
    }

    await workout.deleteOne();

    return res.status(200).json({
      success: true,
      message: 'Workout deleted successfully',
      data: {}
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createWorkout,
  getWorkouts,
  getWorkoutById,
  updateWorkout,
  deleteWorkout
};
