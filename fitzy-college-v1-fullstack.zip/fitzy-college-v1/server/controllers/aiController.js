const { getWorkoutRecommendation, getFitnessInsights } = require('../services/geminiService');

// Kept consistent with the enums already used on the User model.
const VALID_FITNESS_GOALS = ['Weight Loss', 'Muscle Gain', 'Endurance', 'Flexibility', 'General Fitness'];
const VALID_EXPERIENCE_LEVELS = ['Beginner', 'Intermediate', 'Advanced'];

// POST /api/ai/recommendation
const getRecommendation = async (req, res, next) => {
  try {
    const { age, fitnessGoal, experienceLevel } = req.body;

    if (age === undefined || fitnessGoal === undefined || experienceLevel === undefined) {
      return res.status(400).json({
        success: false,
        message: 'age, fitnessGoal, and experienceLevel are required'
      });
    }

    const numericAge = Number(age);
    if (!Number.isInteger(numericAge) || numericAge < 10 || numericAge > 100) {
      return res.status(400).json({
        success: false,
        message: 'age must be a whole number between 10 and 100'
      });
    }

    if (!VALID_FITNESS_GOALS.includes(fitnessGoal)) {
      return res.status(400).json({
        success: false,
        message: `fitnessGoal must be one of: ${VALID_FITNESS_GOALS.join(', ')}`
      });
    }

    if (!VALID_EXPERIENCE_LEVELS.includes(experienceLevel)) {
      return res.status(400).json({
        success: false,
        message: `experienceLevel must be one of: ${VALID_EXPERIENCE_LEVELS.join(', ')}`
      });
    }

    const recommendation = await getWorkoutRecommendation({
      age: numericAge,
      fitnessGoal,
      experienceLevel
    });

    return res.status(200).json({
      success: true,
      message: 'Workout recommendation generated successfully',
      data: recommendation
    });
  } catch (error) {
    // geminiService already guarantees a safe, generic error.message (see
    // services/geminiService.js) — never a raw Gemini/network error. 502
    // signals "the upstream AI service failed", distinct from a 400
    // validation error or a 500 server bug.
    return res.status(502).json({
      success: false,
      message: error.message || 'Failed to generate workout recommendation'
    });
  }
};

// POST /api/ai/insights
const getInsights = async (req, res, next) => {
  try {
    const { totalWorkouts, averageWorkoutDuration, totalCaloriesBurned } = req.body;

    if (
      totalWorkouts === undefined ||
      averageWorkoutDuration === undefined ||
      totalCaloriesBurned === undefined
    ) {
      return res.status(400).json({
        success: false,
        message: 'totalWorkouts, averageWorkoutDuration, and totalCaloriesBurned are required'
      });
    }

    const numericTotalWorkouts = Number(totalWorkouts);
    if (!Number.isInteger(numericTotalWorkouts) || numericTotalWorkouts < 0) {
      return res.status(400).json({
        success: false,
        message: 'totalWorkouts must be a whole number of 0 or more'
      });
    }

    const numericAvgDuration = Number(averageWorkoutDuration);
    if (!Number.isFinite(numericAvgDuration) || numericAvgDuration < 0) {
      return res.status(400).json({
        success: false,
        message: 'averageWorkoutDuration must be a number of 0 or more'
      });
    }

    const numericTotalCalories = Number(totalCaloriesBurned);
    if (!Number.isFinite(numericTotalCalories) || numericTotalCalories < 0) {
      return res.status(400).json({
        success: false,
        message: 'totalCaloriesBurned must be a number of 0 or more'
      });
    }

    const insights = await getFitnessInsights({
      totalWorkouts: numericTotalWorkouts,
      averageWorkoutDuration: numericAvgDuration,
      totalCaloriesBurned: numericTotalCalories
    });

    return res.status(200).json({
      success: true,
      message: 'Fitness insights generated successfully',
      data: insights
    });
  } catch (error) {
    // Same reasoning as getRecommendation: geminiService already guarantees
    // a safe, generic error.message — 502 signals an upstream AI failure.
    return res.status(502).json({
      success: false,
      message: error.message || 'Failed to generate fitness insights'
    });
  }
};

module.exports = { getRecommendation, getInsights };
