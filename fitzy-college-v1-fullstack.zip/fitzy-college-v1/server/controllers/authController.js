const User = require('../models/User');
const { hashPassword, comparePassword } = require('../services/passwordService');
const { generateToken } = require('../services/jwtService');

/**
 * Shapes a User document into the safe object returned to clients.
 * Never includes the password.
 */
const toPublicUser = (user) => ({
  id: user._id,
  name: user.name,
  email: user.email,
  age: user.age,
  fitnessGoal: user.fitnessGoal,
  experienceLevel: user.experienceLevel
});

// POST /api/auth/register
const register = async (req, res, next) => {
  try {
    const { name, email, password, age, fitnessGoal, experienceLevel } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Name, email, and password are required'
      });
    }

    const existingUser = await User.findOne({ email: email.toLowerCase().trim() });
    if (existingUser) {
      return res.status(409).json({
        success: false,
        message: 'A user with this email already exists'
      });
    }

    const hashedPassword = await hashPassword(password);

    const user = await User.create({
      name,
      email,
      password: hashedPassword,
      age,
      fitnessGoal,
      experienceLevel
    });

    const token = generateToken({ id: user._id });

    return res.status(201).json({
      success: true,
      message: 'User registered successfully',
      data: {
        token,
        user: toPublicUser(user)
      }
    });
  } catch (error) {
    next(error);
  }
};

// POST /api/auth/login
const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Email and password are required'
      });
    }

    // Password is select:false on the schema, so it must be explicitly
    // requested here to compare it.
    const user = await User.findOne({ email: email.toLowerCase().trim() }).select('+password');
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password'
      });
    }

    const isMatch = await comparePassword(password, user.password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password'
      });
    }

    const token = generateToken({ id: user._id });

    return res.status(200).json({
      success: true,
      message: 'Login successful',
      data: {
        token,
        user: toPublicUser(user)
      }
    });
  } catch (error) {
    next(error);
  }
};

// GET /api/auth/profile (protected — req.user is set by authMiddleware)
const getProfile = async (req, res, next) => {
  try {
    return res.status(200).json({
      success: true,
      message: 'Profile retrieved successfully',
      data: {
        user: toPublicUser(req.user)
      }
    });
  } catch (error) {
    next(error);
  }
};

module.exports = { register, login, getProfile };
