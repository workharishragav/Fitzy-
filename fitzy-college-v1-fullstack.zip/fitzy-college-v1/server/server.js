require('dotenv').config();

const validateEnv = require('./utils/validateEnv');
validateEnv();

const app = require('./app');
const connectDB = require('./config/db');

const PORT = process.env.PORT || 5000;

connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`Fitzy backend running on port ${PORT}`);
  });
});

