/**
 * Centralized error-handling middleware.
 *
 * Must be mounted LAST in app.js — after every route and after the 404
 * handler — so any error passed via next(error) anywhere in the app
 * (auth, workouts, DB, or an unexpected bug) funnels through here into one
 * consistent response shape, and nothing ever reaches the client as a raw
 * stack trace.
 */
const errorMiddleware = (err, req, res, next) => {
  let statusCode = err.statusCode || 500;
  let message = err.message || 'Internal server error';

  // Malformed JSON body (express.json() throws this before a route ever runs)
  if (err.type === 'entity.parse.failed') {
    statusCode = 400;
    message = 'Invalid JSON in request body';
  }

  // Mongoose validation error — missing/invalid fields on create or save
  if (err.name === 'ValidationError') {
    statusCode = 400;
    message = Object.values(err.errors)
      .map((fieldError) => fieldError.message)
      .join(', ');
  }

  // Mongoose CastError — malformed ObjectId (or wrong type) in a query
  if (err.name === 'CastError') {
    statusCode = 400;
    message = `Invalid ${err.path}: ${err.value}`;
  }

  // MongoDB duplicate key — e.g. a duplicate email that slipped past the
  // explicit pre-check in authController under a race condition
  if (err.code === 11000) {
    statusCode = 409;
    const field = Object.keys(err.keyValue || {})[0] || 'field';
    message = `${field} already in use`;
  }

  // JWT errors that reach here directly (authMiddleware already handles
  // its own token checks with a clean 401 — this is a safety net)
  if (err.name === 'JsonWebTokenError') {
    statusCode = 401;
    message = 'Invalid token';
  }
  if (err.name === 'TokenExpiredError') {
    statusCode = 401;
    message = 'Token expired';
  }

  // Never leak internals for a genuine 500 — log the real error server-side,
  // send a generic message to the client (unless explicitly in dev mode).
  if (statusCode === 500) {
    console.error('Unexpected server error:', err);
    if (process.env.NODE_ENV !== 'development') {
      message = 'Internal server error';
    }
  }

  return res.status(statusCode).json({
    success: false,
    message
  });
};

module.exports = errorMiddleware;
