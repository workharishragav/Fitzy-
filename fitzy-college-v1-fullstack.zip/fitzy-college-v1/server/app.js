const express = require('express');
const cors = require('cors');

const app = express();

// ---------- Global middleware ----------
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ---------- Base route (server health check) ----------
app.get('/', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Fitzy backend is running',
    data: {
      service: 'fitzy-backend',
      status: 'ok'
    }
  });
});

// ---------- Feature routes ----------
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/workouts', require('./routes/workoutRoutes'));
app.use('/api/ai', require('./routes/aiRoutes'));

// ---------- 404 handler for undefined routes ----------
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: `Route not found: ${req.method} ${req.originalUrl}`
  });
});

// NOTE: Centralized error-handling middleware must be mounted here, after
// every route and after the 404 handler, so any next(error) call in the
// app funnels through it.
app.use(require('./middleware/errorMiddleware'));

module.exports = app;
