# Fitzy Backend — Build Progress

## Status: Phase 15 complete — College V1 done

| Phase | Item | Status |
|---|---|---|
| 1 | Project setup | ✅ Done |
| 2 | Express server | ✅ Done |
| 3 | MongoDB connection | ✅ Done |
| 4 | User model | ✅ Done |
| 5 | Authentication | ✅ Done |
| 6 | JWT middleware | ✅ Done |
| 7 | Workout model | ✅ Done |
| 8 | Workout CRUD | ✅ Done |
| 9 | Workout search | ✅ Done |
| 10 | Gemini service | ✅ Done |
| 11 | AI recommendation | ✅ Done |
| 12 | AI fitness insights | ✅ Done |
| 13 | Centralized error handling & security review | ✅ Done |
| 14 | Postman testing | ✅ Done |
| 15 | Documentation | ✅ Done |

All 15 phases complete. Every step in the section 23 "Final Success
Condition" flow (register → hash → login → JWT → protected routes →
workout CRUD → search → AI recommendation → AI insights → error handling →
Postman testing → documentation) is implemented and traceable to a
specific file above.
| 5 | Authentication | Pending |
| 6 | JWT middleware | Pending |
| 7 | Workout model | Pending |
| 8 | Workout CRUD | Pending |
| 9 | Workout search | Pending |
| 10 | Gemini service | Pending |
| 11 | AI recommendation | Pending |
| 12 | AI fitness insights | Pending |
| 13 | Centralized error handling & security review | Pending |
| 14 | Postman testing | Pending |
| 15 | Documentation | Pending |

## Phase 1 — what was done

- Verified no existing project (clean slate).
- Created MVC folder structure:
  `config/ models/ controllers/ routes/ middleware/ services/ utils/`
- `package.json` with exact required stack: express, mongoose, jsonwebtoken,
  bcryptjs, dotenv, cors (+ nodemon as dev dependency).
- `.env.example` with `PORT`, `MONGO_URI`, `JWT_SECRET`, `GEMINI_API_KEY`.
- `.gitignore` excluding `node_modules/` and `.env`.

## Phase 2 — what was done

- `app.js`: Express app with `cors()`, `express.json()`, `express.urlencoded()`,
  a `GET /` health-check route, and a catch-all 404 handler in the standard
  `{ success, message }` response shape.
- `server.js`: entry point — loads `.env` via `dotenv`, imports `app.js`,
  listens on `process.env.PORT` (default 5000).
- Feature routes (`/api/auth`, `/api/workouts`, `/api/ai`) are commented as
  wiring points in `app.js` but not mounted — those routers don't exist yet.

## Phase 3 — what was done

- `config/db.js`: `connectDB()` — connects Mongoose to `process.env.MONGO_URI`,
  logs the connected host/db name, exits the process with a clear error if
  `MONGO_URI` is missing or the connection fails, and attaches `error`/
  `disconnected` listeners for runtime issues after the initial connect.
- `server.js`: now calls `connectDB()` and only starts `app.listen()` after
  the connection resolves — the server won't come up without a working DB
  connection.

**Verification (Phases 2 & 3):** `node --check` passed on all files. Could not
run a live server boot or DB connection test — no MongoDB instance and no
outbound network access in this sandbox. To confirm on your machine:
```
# have MongoDB running locally (or a valid Atlas URI in .env)
cd server
npm install
npm run dev
# should log: "MongoDB connected: ..." then "Fitzy backend running on port 5000"
# then visit http://localhost:5000/ for the health-check JSON
```

## Phase 4 — what was done

- `models/User.js`: Mongoose schema with `name`, `email`, `password`, `age`,
  `fitnessGoal`, `experienceLevel`, plus auto `createdAt`/`updatedAt` via
  `timestamps: true`.
  - `email`: required, unique, trimmed, lowercased, regex-validated.
  - `password`: required, min length 6, `select: false` so it's excluded
    from query results by default; a `toJSON` transform also strips it
    (and `__v`) as a second safety net if it's ever explicitly selected.
  - `fitnessGoal` / `experienceLevel`: optional enums matching the values
    used in the AI recommendation spec examples.
- **Deliberately not included yet:** password hashing. Hashing belongs to
  Phase 5 (Authentication) via `services/passwordService.js` — the model
  only defines the field/validation, not the hashing logic.

**Verification:** `node --check` passed.

## Phase 5 — what was done

- `services/passwordService.js`: `hashPassword()` / `comparePassword()` using
  bcryptjs (10 salt rounds).
- `services/jwtService.js`: `generateToken(payload)` / `verifyToken(token)`
  using `JWT_SECRET`, 7-day expiry.
- `controllers/authController.js`: `register` and `login`.
  - `register`: validates required fields, rejects duplicate email (409),
    hashes the password via `passwordService`, creates the user, returns a
    JWT + safe user object (no password).
  - `login`: validates input, looks up the user with `.select('+password')`
    (needed since the schema hides it by default), compares via
    `passwordService`, returns a JWT + safe user object on success, a
    generic 401 on failure (doesn't reveal whether the email exists).
  - Errors are passed to `next(error)` — there's no centralized error
    handler mounted yet (that's Phase 13), so until then Express's default
    handler catches anything unexpected.
- `routes/authRoutes.js`: `POST /register`, `POST /login`. Mounted in
  `app.js` at `/api/auth`.

**Intentionally not done — held for Phase 6:** `GET /api/auth/profile`.
The spec requires it to be JWT-protected, which means it depends on
`middleware/authMiddleware.js` populating `req.user` — that middleware
doesn't exist yet. Building the route now would mean either leaving it
unprotected (violates the spec) or requiring a middleware file that isn't
there yet. So `getProfile` and its route are deferred to Phase 6, right
after the middleware is built.

**Verification:** `node --check` passed on all new/changed files
(`passwordService.js`, `jwtService.js`, `authController.js`,
`authRoutes.js`, `app.js`). Live endpoint testing (Postman) needs a running
Mongo + `npm install`, which this sandbox can't do — full testing is
Phase 14.

## Phase 6 — what was done

- `middleware/authMiddleware.js`: `protect` — reads `Authorization: Bearer <token>`,
  returns 401 if missing/malformed, verifies via `jwtService.verifyToken`
  (401 on invalid/expired), loads the user by the token's `id` (401 if the
  user no longer exists), attaches the user document to `req.user`, calls
  `next()`.
- `controllers/authController.js`: added `getProfile` — returns
  `toPublicUser(req.user)`. Now exports `{ register, login, getProfile }`.
- `routes/authRoutes.js`: added `router.get('/profile', protect, getProfile)`.

The full authentication flow spec'd in section 2 is now complete: register →
login → JWT → protected profile retrieval.

**Verification:** `node --check` passed on all three touched files.

## Phase 7 — what was done

- `models/Workout.js`: Mongoose schema with `user` (ObjectId ref → `User`,
  required — the "one User → many Workouts" relationship), `workoutName`
  (required), `category` (required, enum: Cardio/Strength/Flexibility/
  HIIT/Yoga/Sports/Other), `duration` (minutes, required, min 1),
  `caloriesBurned` (required, min 0), `workoutDate` (required, defaults to
  now), plus auto `createdAt`/`updatedAt` via `timestamps: true`.
- Added an index on `user` — every workout query in upcoming phases (CRUD,
  ownership checks, search) filters by the owning user, so this keeps those
  lookups fast.

**Deliberately not included yet:** any routes/controllers touching this
model — that's Phase 8 (CRUD) and Phase 9 (search).

**Verification:** `node --check` passed.

## Phase 8 — what was done

- `controllers/workoutController.js`: `createWorkout`, `getWorkouts`,
  `getWorkoutById`, `updateWorkout`, `deleteWorkout`.
  - Every workout is created with `user: req.user._id` from the JWT — never
    from the request body, so a client can't create a workout on someone
    else's behalf.
  - `getWorkouts` is scoped with `Workout.find({ user: req.user._id })` —
    a user only ever sees their own list.
  - `getWorkoutById` / `updateWorkout` / `deleteWorkout` all: validate the
    `:id` is a well-formed ObjectId (400 if not, so a malformed ID doesn't
    fall through to an uncaught cast error), 404 if no workout exists with
    that ID, then an explicit ownership check (`workout.user` vs
    `req.user._id`) returning 403 if it belongs to someone else. 403 (not a
    disguised 404) was chosen so the "access another user's workout" test
    case from section 19 is unambiguous to verify.
  - `update` only applies fields actually present in the request body, then
    `.save()`s so schema validation still runs.
- `routes/workoutRoutes.js`: `router.use(protect)` — every route in this
  file requires a valid JWT — then `POST /`, `GET /`, `GET /:id`, `PUT /:id`,
  `DELETE /:id`. Mounted at `/api/workouts` in `app.js`.

**Deliberately not included yet:** search/filter query params (`search`,
`category`, `date`) on `GET /api/workouts` — that's Phase 9.

**Verification:** `node --check` passed on all three touched files.

## Phase 9 — what was done

- `controllers/workoutController.js`: `getWorkouts` extended (not
  replaced) to read optional query params, all combinable:
  - `search` → case-insensitive partial match on `workoutName`
  - `category` → case-insensitive exact match on `category` (so
    `?category=cardio` matches the stored `"Cardio"`)
  - `date` → matches any workout whose `workoutDate` falls within that
    calendar day (UTC start/end of day); returns 400 on an unparseable date
  - All filters always include `user: req.user._id`, so search results
    stay scoped to the caller — search never becomes a way to see other
    users' workouts.
  - Added an `escapeRegex` helper so `search`/`category` input is always
    treated as a literal string, never interpreted as a regex pattern.
- No route or endpoint changes — still `GET /api/workouts`, just smarter now.

**Verification:** `node --check` passed.

## Phase 10 — what was done

- `services/geminiService.js`: `callGemini(prompt)` — the single, dedicated
  choke point for all Gemini API calls (routes/controllers must never call
  Gemini directly, per the required architecture:
  Route → Controller → Gemini Service → Gemini API → Client).
  - Reads `GEMINI_API_KEY` from `process.env` only — never hardcoded.
  - Uses Node's built-in `https` module (no new dependency — `axios` etc.
    aren't in the required stack, and Node 16+ doesn't have global `fetch`).
  - Sends the prompt to the `gemini-1.5-flash` model's `generateContent`
    endpoint, extracts `candidates[0].content.parts[0].text`.
  - On any failure (missing key, network error, non-2xx response, unusable
    response shape), logs the real reason server-side with `console.error`
    and rejects with a **generic** `Error` — never the raw Gemini error,
    a stack trace, or anything that could contain the API key.
- This is the reusable foundation only — it takes an already-built prompt
  string. Feature-specific prompt construction (the actual recommendation
  and insights prompts) is added to this same file in Phase 11 and 12,
  each calling `callGemini` rather than duplicating the HTTP logic.

**Not yet wired anywhere** — no controller or route calls this yet. That
starts in Phase 11.

**Verification:** `node --check` passed. Could not make a live call — no
`GEMINI_API_KEY` configured and no network access in this sandbox. Live
verification happens once you add a real key and test via Postman
(Phase 14).

## Phase 11 — what was done

- `services/geminiService.js` extended (not replaced):
  - `parseJsonResponse(rawText)` — strips markdown code fences Gemini
    sometimes adds even when told not to, then `JSON.parse`s; throws a
    generic (safe) Error if the result still isn't valid JSON.
  - `buildRecommendationPrompt({ age, fitnessGoal, experienceLevel })` —
    constructs a controlled prompt that instructs Gemini to return ONLY
    JSON matching an exact structure: `workoutPlan`, `weeklySchedule`,
    `trainingGuidance`, `motivationalGuidance`, `safetyRecommendations`,
    and a `disclaimer` field explicitly stating this is general fitness
    guidance, not medical advice.
  - `getWorkoutRecommendation(...)` — builds the prompt, calls `callGemini`,
    parses the JSON, returns it. Newly exported alongside `callGemini`.
- `controllers/aiController.js` (new): `getRecommendation` — validates
  `age` (integer 10–100), `fitnessGoal` (must match the User model's
  enum), `experienceLevel` (Beginner/Intermediate/Advanced) *before*
  calling Gemini; on AI failure, responds `502` with the already-safe
  message from `geminiService` (never a raw error or stack trace).
- `routes/aiRoutes.js` (new): `POST /recommendation`, mounted at `/api/ai`
  in `app.js`.

**Design call — AI routes are JWT-protected**, via `router.use(protect)`,
same as workouts. The spec doesn't explicitly list an "unauthorized AI
request" test case the way it does for workouts, so this is somewhat
ambiguous — but the overall app treats every other data-touching endpoint
as requiring auth, and the "Final Success Condition" flow (section 23)
places AI Recommendation *after* JWT Authentication in the sequence. Protecting
it keeps the security model consistent. Flag if you want it public instead —
easy one-line change (drop `router.use(protect)`).

**Verification:** `node --check` passed on all four touched/new files. The
fence-stripping regex in `parseJsonResponse` was sanity-tested standalone
against a markdown-wrapped JSON string. No live Gemini call was possible —
no API key configured, no network access in this sandbox.

## Phase 12 — what was done

- `services/geminiService.js` extended: `buildInsightsPrompt(...)` (same
  controlled-JSON-only pattern as the recommendation prompt — returns
  `performanceAnalysis`, `improvementSuggestions`, `motivationalAdvice`,
  `progressSummary`, and a non-medical-advice `disclaimer`) and
  `getFitnessInsights(...)`, now also exported.
- `controllers/aiController.js`: `getInsights` — validates `totalWorkouts`
  (non-negative integer), `averageWorkoutDuration` and `totalCaloriesBurned`
  (non-negative numbers) before calling Gemini; same 502-with-safe-message
  pattern on AI failure as `getRecommendation`.
- `routes/aiRoutes.js`: added `POST /insights` alongside `/recommendation`,
  both under the same `protect` middleware.

Both AI features from the spec (recommendation + insights) are now
implemented end-to-end: validated input → controlled prompt → Gemini →
parsed structured JSON → client.

**Verification:** `node --check` passed on all three touched files. No live
Gemini call possible in this sandbox (no key, no network) — that's for
Phase 14 (Postman testing) once you have a real `GEMINI_API_KEY`.

## Phase 13 — what was done

**Centralized error handling:**
- `middleware/errorMiddleware.js` — mounted last in `app.js` (after every
  route and after the 404 handler), catches everything passed to
  `next(error)` across the app and returns one consistent
  `{ success: false, message }` shape:
  - Malformed JSON body → 400
  - Mongoose `ValidationError` (bad/missing fields on create or save) → 400
    with the field error messages joined together
  - Mongoose `CastError` (malformed ObjectId that slips through) → 400
  - MongoDB duplicate-key error (code 11000) → 409 — a safety net behind
    the explicit duplicate-email check already in `authController`
  - `JsonWebTokenError` / `TokenExpiredError` → 401 — a safety net behind
    `authMiddleware`'s own handling
  - Anything else → 500, logged in full server-side via `console.error`,
    but the client only ever gets a generic "Internal server error"
    (unless `NODE_ENV=development`) — never a stack trace.
- Concretely, this closes a real gap: before this phase, a Mongoose
  validation error from e.g. `POST /api/workouts` with a bad `category`
  would have hit Express's default handler and returned an HTML page with
  a stack trace. Now it returns clean JSON: `400` with the actual
  validation message.

**Security review — findings and fixes:**
- Added `utils/validateEnv.js`, called at the top of `server.js` right
  after `dotenv.config()`. Fails fast with a clear console message if
  `PORT`, `MONGO_URI`, `JWT_SECRET`, or `GEMINI_API_KEY` is missing,
  instead of the app starting and failing confusingly later (a cryptic
  `jwt.sign` error, or every Gemini call silently rejecting).
- Swept the whole `server/` tree for hardcoded secrets and for any
  `console.log` of `req.body`, passwords, or tokens — none found.
- Re-confirmed `password: { select: false }` is intact on the User schema
  and `.env` is in `.gitignore`.
- Reviewed each controller's error path: `authController` and
  `workoutController` use `next(error)` — now properly caught by this
  phase's middleware; `aiController` deliberately catches its own errors
  and returns 502 directly (already safe, generic messages from
  `geminiService` — no change needed there).
- Noted but left as-is: `cors()` with default (all-origins-allowed)
  config. Reasonable for a college project tested via Postman; flagging
  it here in case you want to restrict it before any real deployment.

**Verification:** `node --check` passed on `errorMiddleware.js`,
`validateEnv.js`, `server.js`, and `app.js`.

## Phase 14 — what was done

- `postman/Fitzy-College-V1.postman_collection.json` — a Postman v2.1
  collection covering every test case listed in the spec's section 19,
  organized into three folders that are meant to be run top-to-bottom
  (Collection Runner, in order):
  - **Authentication (9 requests):** Register Success, Register Duplicate
    Email, Register Invalid Input, Login Success, Login Wrong Password,
    Login Unknown User, Profile With Valid JWT, Profile Without JWT,
    Profile With Invalid JWT.
  - **Workout (12 requests):** the 11 spec'd cases — Create, Get All, Get
    By ID, Update, Search by Name, Search by Category, Search by Date,
    Unauthorized Access, Invalid ID, Access Another User's Workout,
    Delete — plus one supporting request ("Register Second User") needed
    to set up the cross-user test.
  - **AI (5 requests):** Valid Recommendation, Invalid Recommendation,
    Valid Fitness Insight, Invalid Fitness Insight, Gemini/API Failure
    Handling.
- Each request has `pm.test` assertions (status code + response shape),
  and collection variables (`token`, `testEmail`, `userId`, `workoutId`,
  `secondUserToken`) are set by test scripts on earlier requests and
  consumed by later ones — the collection is self-contained and re-runnable
  (registration uses `{{$timestamp}}` in the email so re-runs don't collide
  on duplicate emails).
- The two AI-success requests accept either `200` or `502`, since a real
  result depends on a working `GEMINI_API_KEY` and network access outside
  this sandbox — the "Gemini/API Failure Handling" request specifically
  documents how to force the failure path (invalidate the key, restart,
  re-run) and automatically checks that a `502` response never leaks the
  API key or a raw error.
- `baseUrl` defaults to `http://localhost:5000` — change the collection
  variable if you run the server on a different port.

**Verification:** The generated JSON was parsed and its structure printed
to confirm it's well-formed and every request landed in the right folder —
26 requests total (9 + 12 + 5), matching the spec exactly. **Could not
actually run the collection** — that requires the live server (Mongo +
Gemini key), which isn't available in this sandbox. Import it into Postman
and run it with `npm run dev` going to confirm end-to-end.

## Phase 15 — what was done

- `README.md` (new, at project root) — the actual project documentation,
  distinct from this build log: tech stack, architecture diagram, full
  folder structure, setup steps, an environment variable table, complete
  API reference (every endpoint, auth requirement, body shape) for auth,
  workouts, and AI, the error-handling model, how to run the Postman
  collection, a security-notes summary, and an explicit "not included in
  College V1" section mirroring the spec's exclusion list.
- Final full-project verification before closing out: `node --check` run
  against all 17 `.js` files in the project — all pass — and the complete
  file tree was listed and reviewed.

## College V1: complete

All 15 phases are done. Nothing further is planned unless you ask for a
specific change, a new feature, or want to move into the (explicitly
out-of-scope-for-now) business-layer features listed in the spec's
section 21.
