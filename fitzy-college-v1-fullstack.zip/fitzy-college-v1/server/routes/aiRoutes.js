const express = require('express');
const { getRecommendation, getInsights } = require('../controllers/aiController');
const { protect } = require('../middleware/authMiddleware');

const router = express.Router();

// Protected, consistent with the rest of the app's security model — see
// PROGRESS.md (Phase 11) for the reasoning, since the spec doesn't
// explicitly call this out for the AI module the way it does for workouts.
router.use(protect);

router.post('/recommendation', getRecommendation);
router.post('/insights', getInsights);

module.exports = router;
