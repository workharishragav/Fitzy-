const mongoose = require('mongoose');

const workoutSchema = new mongoose.Schema(
  {
    // One User -> Many Workouts
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'A workout must belong to a user']
    },
    workoutName: {
      type: String,
      required: [true, 'Workout name is required'],
      trim: true
    },
    category: {
      type: String,
      required: [true, 'Category is required'],
      trim: true,
      enum: {
        values: ['Cardio', 'Strength', 'Flexibility', 'HIIT', 'Yoga', 'Sports', 'Other'],
        message: '{VALUE} is not a supported workout category'
      }
    },
    duration: {
      type: Number,
      required: [true, 'Duration (in minutes) is required'],
      min: [1, 'Duration must be at least 1 minute']
    },
    caloriesBurned: {
      type: Number,
      required: [true, 'Calories burned is required'],
      min: [0, 'Calories burned cannot be negative']
    },
    workoutDate: {
      type: Date,
      required: [true, 'Workout date is required'],
      default: Date.now
    }
  },
  {
    timestamps: true // adds createdAt and updatedAt automatically
  }
);

// Every workout query is scoped to a user (ownership checks, listing,
// search) — index it so those lookups stay fast as data grows.
workoutSchema.index({ user: 1 });

module.exports = mongoose.model('Workout', workoutSchema);
