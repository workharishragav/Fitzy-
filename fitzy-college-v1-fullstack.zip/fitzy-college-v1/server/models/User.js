const mongoose = require('mongoose');

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Name is required'],
      trim: true
    },
    email: {
      type: String,
      required: [true, 'Email is required'],
      unique: true,
      trim: true,
      lowercase: true,
      match: [
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
        'Please provide a valid email address'
      ]
    },
    password: {
      type: String,
      required: [true, 'Password is required'],
      minlength: [6, 'Password must be at least 6 characters long'],
      // Excluded from query results by default so it never accidentally
      // leaks into a normal API response (e.g. GET /api/auth/profile).
      select: false
    },
    age: {
      type: Number,
      min: [10, 'Age must be at least 10'],
      max: [100, 'Age must be at most 100']
    },
    fitnessGoal: {
      type: String,
      enum: {
        values: ['Weight Loss', 'Muscle Gain', 'Endurance', 'Flexibility', 'General Fitness'],
        message: '{VALUE} is not a supported fitness goal'
      }
    },
    experienceLevel: {
      type: String,
      enum: {
        values: ['Beginner', 'Intermediate', 'Advanced'],
        message: '{VALUE} is not a supported experience level'
      }
    }
  },
  {
    timestamps: true, // adds createdAt and updatedAt automatically
    toJSON: {
      transform: (doc, ret) => {
        // Extra safety net: strip password and __v even if a query
        // ever explicitly selects the password field back in.
        delete ret.password;
        delete ret.__v;
        return ret;
      }
    }
  }
);

module.exports = mongoose.model('User', userSchema);
