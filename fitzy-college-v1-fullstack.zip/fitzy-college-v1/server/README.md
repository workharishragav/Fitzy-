# Fitzy — College V1 Backend

Personalized fitness recommendations powered by AI. A secure, modular
RESTful backend for workout tracking with Google Gemini-powered
personalized workout recommendations and fitness insights.

Built for a Naan Mudhalvan college project. This is **College V1** only —
see [Scope](#scope--not-included-in-college-v1) below for what's
deliberately left out.

---

## Tech stack

- Node.js (v16+)
- Express.js
- MongoDB + Mongoose
- JWT (`jsonwebtoken`) for authentication
- `bcryptjs` for password hashing
- Google Gemini API for AI recommendations/insights
- `dotenv`, `cors`

Architecture: **MVC + layered** — routes never call the database or Gemini
directly; controllers own request/response handling; models own data
validation; services own reusable logic (password hashing, JWT, Gemini
calls).

```
Route  →  Controller  →  Service / Model  →  Client
```

## Project structure

```
server/
├── config/
│   └── db.js                 MongoDB connection
├── models/
│   ├── User.js
│   └── Workout.js
├── controllers/
│   ├── authController.js
│   ├── workoutController.js
│   └── aiController.js
├── routes/
│   ├── authRoutes.js
│   ├── workoutRoutes.js
│   └── aiRoutes.js
├── middleware/
│   ├── authMiddleware.js     JWT verification (protect)
│   └── errorMiddleware.js    Centralized error handling
├── services/
│   ├── geminiService.js      All Gemini API calls live here
│   ├── jwtService.js
│   └── passwordService.js
├── utils/
│   └── validateEnv.js        Fail-fast startup config check
├── postman/
│   └── Fitzy-College-V1.postman_collection.json
├── app.js                    Express app, middleware, route mounting
├── server.js                 Entry point
├── package.json
├── .env.example
├── .gitignore
├── README.md                 (this file)
└── PROGRESS.md                Phase-by-phase build log
```

## Setup

1. **Install dependencies**
   ```
   cd server
   npm install
   ```

2. **Configure environment variables** — copy the example file and fill in
   real values:
   ```
   cp .env.example .env
   ```

   | Variable | Description |
   |---|---|
   | `PORT` | Port the server listens on (default `5000`) |
   | `MONGO_URI` | MongoDB connection string, e.g. `mongodb://localhost:27017/aifittrack` |
   | `JWT_SECRET` | Secret used to sign JWTs — use a long random string |
   | `GEMINI_API_KEY` | Your Google Gemini API key |

   The server checks these at startup (`utils/validateEnv.js`) and exits
   with a clear message if any are missing — never commit the real `.env`
   file (it's already in `.gitignore`).

3. **Run it**
   ```
   npm run dev     # nodemon, auto-restart on change
   # or
   npm start       # plain node
   ```
   On success you'll see `MongoDB connected: ...` followed by
   `Fitzy backend running on port 5000`. Visit `http://localhost:5000/` for
   a health-check response.

## API reference

All responses use the same shape:
```json
{ "success": true,  "message": "...", "data": { } }
{ "success": false, "message": "..." }
```

🔒 = requires `Authorization: Bearer <token>` header.

### Authentication — `/api/auth`

| Method | Path | Auth | Body |
|---|---|---|---|
| POST | `/register` | — | `{ name, email, password, age?, fitnessGoal?, experienceLevel? }` |
| POST | `/login` | — | `{ email, password }` |
| GET | `/profile` | 🔒 | — |

Register/login both return `{ token, user }` in `data` on success. The
user object never includes the password field.

### Workouts — `/api/workouts` (all routes 🔒)

| Method | Path | Body / Query |
|---|---|---|
| POST | `/` | `{ workoutName, category, duration, caloriesBurned, workoutDate? }` |
| GET | `/` | optional `?search=&category=&date=YYYY-MM-DD` (combinable) |
| GET | `/:id` | — |
| PUT | `/:id` | any subset of the create fields |
| DELETE | `/:id` | — |

`category` must be one of: `Cardio, Strength, Flexibility, HIIT, Yoga,
Sports, Other`. Every workout is scoped to the authenticated user — you can
only see, update, or delete your own (attempting another user's workout
returns `403`).

### AI — `/api/ai` (all routes 🔒)

| Method | Path | Body |
|---|---|---|
| POST | `/recommendation` | `{ age, fitnessGoal, experienceLevel }` |
| POST | `/insights` | `{ totalWorkouts, averageWorkoutDuration, totalCaloriesBurned }` |

`fitnessGoal` must be one of the User model's enum values (`Weight Loss,
Muscle Gain, Endurance, Flexibility, General Fitness`); `experienceLevel`
one of `Beginner, Intermediate, Advanced`. Both endpoints validate input
before ever calling Gemini, and return a structured JSON object in `data`
(plan/insights + an explicit disclaimer that this is general fitness
guidance, not medical advice). If Gemini itself fails, the response is a
safe generic `502` — never a raw error or the API key.

## Error handling

A single centralized middleware (`middleware/errorMiddleware.js`, mounted
last in `app.js`) turns every internal failure into the standard response
shape above with an appropriate status code — validation errors → 400,
duplicate email → 409, auth failures → 401, ownership failures → 403, not
found → 404, upstream AI failure → 502, anything unexpected → 500 (logged
in full server-side, generic message to the client). Stack traces are
never sent to the client.

## Testing

Import `postman/Fitzy-College-V1.postman_collection.json` into Postman and
run it with the Collection Runner, **top to bottom** — later requests
depend on variables (`token`, `testEmail`, `workoutId`, `secondUserToken`)
set by earlier ones. Set the `baseUrl` collection variable if your server
isn't on `http://localhost:5000`. 26 requests across Authentication (9),
Workout (12), and AI (5), matching every case in the project spec.

## Security notes

- Passwords are hashed with bcrypt (`services/passwordService.js`) and
  never returned in any API response (`select: false` on the schema, plus
  a `toJSON` transform as a second safety net).
- JWTs are signed with `JWT_SECRET` from the environment, 7-day expiry.
- All workout and AI routes require a valid JWT; workouts are additionally
  scoped so one user can never read, edit, or delete another's data.
- The Gemini API key is read from the environment only, never hardcoded,
  never logged, never returned to the client — even on failure.
- `cors()` currently allows all origins, which is fine for local Postman
  testing; tighten this before any real deployment.

## Scope — not included in College V1

Per the project spec, none of the following are implemented and are
intentionally out of scope for this version: gym management, an admin
dashboard, membership plans/payments, attendance, trainers, multi-gym
support, notifications, social features, nutrition tracking, wearable
integrations, voice AI, or any other business/SaaS-layer feature.

## Full flow (what "College V1 complete" means)

Registration → password hashing → login → JWT → protected routes → create
workout → MongoDB storage → retrieve → search → update → delete → AI
recommendation → AI fitness insights → centralized error handling →
Postman testing → documentation (this file). Every step above is
implemented and covered by the Postman collection.
