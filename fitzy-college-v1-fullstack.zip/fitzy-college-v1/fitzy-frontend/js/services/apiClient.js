// Centralized fetch wrapper for the Fitzy backend.
// Every service module (auth/workout/ai) calls through this — no page or
// component ever calls fetch() directly, so auth headers and error
// handling stay in exactly one place.

import { getToken, clearAuth } from '../state/store.js';

export class ApiError extends Error {
  constructor(message, status, data) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.data = data;
  }
}

function apiBaseUrl() {
  return (window.FITZY_CONFIG && window.FITZY_CONFIG.apiBaseUrl) || 'http://localhost:5000';
}

/**
 * @param {string} path - e.g. '/api/auth/login'
 * @param {{method?: string, body?: any, auth?: boolean}} options
 */
export async function apiRequest(path, options = {}) {
  const { method = 'GET', body, auth = true } = options;

  const headers = { 'Content-Type': 'application/json' };
  if (auth) {
    const token = getToken();
    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }
  }

  let response;
  try {
    response = await fetch(`${apiBaseUrl()}${path}`, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined
    });
  } catch (networkError) {
    throw new ApiError(
      'Could not reach the Fitzy backend. Is it running, and is the API URL in js/config.js correct?',
      0,
      null
    );
  }

  let data = null;
  const text = await response.text();
  if (text) {
    try {
      data = JSON.parse(text);
    } catch (parseError) {
      // Non-JSON response body (shouldn't normally happen against this API)
      data = null;
    }
  }

  if (!response.ok) {
    // An expired/invalid token: clear local auth state so the next
    // protected navigation redirects to login instead of looping on 401s.
    if (response.status === 401) {
      clearAuth();
    }
    const message = (data && data.message) || `Request failed (${response.status})`;
    throw new ApiError(message, response.status, data);
  }

  return data;
}
