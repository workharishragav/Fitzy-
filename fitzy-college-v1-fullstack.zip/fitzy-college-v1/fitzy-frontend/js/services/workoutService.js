// Workout service — wraps the /api/workouts endpoints.

import { apiRequest } from './apiClient.js';

/** @param {{workoutName: string, category: string, duration: number, caloriesBurned: number, workoutDate?: string}} input */
export async function createWorkout(input) {
  const res = await apiRequest('/api/workouts', { method: 'POST', body: input });
  return res.data.workout;
}

/**
 * @param {{search?: string, category?: string, date?: string}} filters
 */
export async function listWorkouts(filters = {}) {
  const params = new URLSearchParams();
  if (filters.search) params.set('search', filters.search);
  if (filters.category) params.set('category', filters.category);
  if (filters.date) params.set('date', filters.date);
  const qs = params.toString();
  const res = await apiRequest(`/api/workouts${qs ? `?${qs}` : ''}`, { method: 'GET' });
  return res.data.workouts;
}

export async function getWorkout(id) {
  const res = await apiRequest(`/api/workouts/${encodeURIComponent(id)}`, { method: 'GET' });
  return res.data.workout;
}

export async function updateWorkout(id, input) {
  const res = await apiRequest(`/api/workouts/${encodeURIComponent(id)}`, {
    method: 'PUT',
    body: input
  });
  return res.data.workout;
}

export async function deleteWorkout(id) {
  await apiRequest(`/api/workouts/${encodeURIComponent(id)}`, { method: 'DELETE' });
}
