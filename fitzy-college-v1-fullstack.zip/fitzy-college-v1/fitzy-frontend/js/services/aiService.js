// AI service — wraps the /api/ai endpoints. Returns exactly what the
// backend's Gemini-backed controllers send back; this file does not
// reshape, mock, or invent any of the response content.

import { apiRequest } from './apiClient.js';

/** @param {{age: number, fitnessGoal: string, experienceLevel: string}} input */
export async function getRecommendation(input) {
  const res = await apiRequest('/api/ai/recommendation', { method: 'POST', body: input });
  return res.data;
}

/** @param {{totalWorkouts: number, averageWorkoutDuration: number, totalCaloriesBurned: number}} input */
export async function getInsights(input) {
  const res = await apiRequest('/api/ai/insights', { method: 'POST', body: input });
  return res.data;
}
