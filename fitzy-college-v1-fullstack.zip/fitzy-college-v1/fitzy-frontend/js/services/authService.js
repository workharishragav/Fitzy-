// Auth service — wraps the /api/auth endpoints. Pages call these
// functions; nothing outside this file and apiClient.js knows what the
// HTTP requests actually look like.

import { apiRequest } from './apiClient.js';
import { setAuth, clearAuth, getUser, setUser } from '../state/store.js';

/**
 * @param {{name: string, email: string, password: string, age?: number, fitnessGoal?: string, experienceLevel?: string}} input
 */
export async function register(input) {
  const res = await apiRequest('/api/auth/register', {
    method: 'POST',
    body: input,
    auth: false
  });
  setAuth(res.data.token, res.data.user);
  return res.data.user;
}

export async function login(email, password) {
  const res = await apiRequest('/api/auth/login', {
    method: 'POST',
    body: { email, password },
    auth: false
  });
  setAuth(res.data.token, res.data.user);
  return res.data.user;
}

export async function fetchProfile() {
  const res = await apiRequest('/api/auth/profile', { method: 'GET' });
  return res.data.user;
}

/**
 * Refreshes the cached profile from the backend and updates local storage.
 * Used after a profile-affecting action, or to confirm the token is still
 * valid on app load.
 */
export async function refreshProfile() {
  const user = await fetchProfile();
  setUser(user);
  return user;
}

export function logout() {
  clearAuth();
}

export function currentUser() {
  return getUser();
}
