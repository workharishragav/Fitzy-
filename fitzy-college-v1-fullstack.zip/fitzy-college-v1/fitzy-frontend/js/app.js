import { isAuthenticated, onAuthChange } from './state/store.js';
import { renderHeader } from './components/header.js';
import { renderBottomNav } from './components/bottomNav.js';

import * as loginPage from './pages/login.js';
import * as registerPage from './pages/register.js';
import * as dashboardPage from './pages/dashboard.js';
import * as workoutHistoryPage from './pages/workoutHistory.js';
import * as addWorkoutPage from './pages/addWorkout.js';
import * as editWorkoutPage from './pages/editWorkout.js';
import * as workoutDetailsPage from './pages/workoutDetails.js';
import * as aiRecommendationPage from './pages/aiRecommendation.js';
import * as aiInsightsPage from './pages/aiInsights.js';
import * as profilePage from './pages/profile.js';

// Each route: a path pattern (":id" = param), which nav item it highlights,
// the page module to render, whether it requires auth, and whether the
// app shell (header + bottom nav) is shown for it.
const ROUTES = [
  { pattern: 'login', navKey: null, page: loginPage, auth: false, shell: false },
  { pattern: 'register', navKey: null, page: registerPage, auth: false, shell: false },
  { pattern: 'dashboard', navKey: 'dashboard', page: dashboardPage, auth: true, shell: true },
  { pattern: 'workouts', navKey: 'workouts', page: workoutHistoryPage, auth: true, shell: true },
  { pattern: 'workouts/new', navKey: 'workouts', page: addWorkoutPage, auth: true, shell: true },
  { pattern: 'workouts/:id/edit', navKey: 'workouts', page: editWorkoutPage, auth: true, shell: true },
  { pattern: 'workouts/:id', navKey: 'workouts', page: workoutDetailsPage, auth: true, shell: true },
  { pattern: 'ai/recommendation', navKey: 'ai-recommendation', page: aiRecommendationPage, auth: true, shell: true },
  { pattern: 'ai/insights', navKey: 'ai-recommendation', page: aiInsightsPage, auth: true, shell: true },
  { pattern: 'profile', navKey: 'profile', page: profilePage, auth: true, shell: true }
];

function parseHash() {
  const raw = window.location.hash.replace(/^#\/?/, '').replace(/\/$/, '');
  return raw || 'dashboard';
}

function matchRoute(path) {
  const pathParts = path.split('/').filter(Boolean);
  for (const route of ROUTES) {
    const patternParts = route.pattern.split('/').filter(Boolean);
    if (patternParts.length !== pathParts.length) continue;
    const params = {};
    let matched = true;
    for (let i = 0; i < patternParts.length; i++) {
      if (patternParts[i].startsWith(':')) {
        params[patternParts[i].slice(1)] = decodeURIComponent(pathParts[i]);
      } else if (patternParts[i] !== pathParts[i]) {
        matched = false;
        break;
      }
    }
    if (matched) return { route, params };
  }
  return null;
}

let headerEl;
let bottomNavEl;
let footerEl;
let mainEl;

function renderShell(navKey) {
  headerEl.innerHTML = renderHeader(navKey);
  bottomNavEl.innerHTML = renderBottomNav(navKey);
}

async function handleRouteChange() {
  const path = parseHash();
  const match = matchRoute(path) || matchRoute('dashboard');
  const { route, params } = match;

  if (route.auth && !isAuthenticated()) {
    window.location.hash = '#/login';
    return;
  }
  if (!route.auth && isAuthenticated() && (route.pattern === 'login' || route.pattern === 'register')) {
    window.location.hash = '#/dashboard';
    return;
  }

  document.body.classList.toggle('has-shell', route.shell);
  headerEl.classList.toggle('hidden', !route.shell);
  bottomNavEl.parentElement.classList.toggle('hidden', !route.shell);
  footerEl.classList.toggle('hidden', !route.shell);
  mainEl.classList.toggle('pt-16', route.shell);
  mainEl.classList.toggle('pb-24', route.shell);
  mainEl.classList.toggle('md:pb-12', route.shell);

  if (route.shell) {
    renderShell(route.navKey);
  }

  mainEl.innerHTML = '';
  mainEl.classList.add('fitzy-fade-in');
  window.scrollTo(0, 0);

  try {
    await route.page.render(mainEl, params);
  } catch (error) {
    // Last-resort safety net: a page module throwing synchronously (a bug,
    // not an expected API error — those are already handled inside each
    // page) shouldn't leave the user on a blank screen.
    console.error('Unhandled page render error:', error);
    mainEl.innerHTML = `
      <div class="max-w-2xl mx-auto px-margin-mobile md:px-margin py-space-xl">
        <div class="p-space-lg rounded-2xl bg-error-container text-on-error-container">
          <h2 class="font-title-sm text-title-sm">Something went wrong loading this page.</h2>
          <p class="font-body-sm text-body-sm mt-1">Try going back to your <a href="#/dashboard" class="underline font-semibold">dashboard</a>.</p>
        </div>
      </div>
    `;
  }
}

function bootstrap() {
  headerEl = document.getElementById('app-header');
  bottomNavEl = document.getElementById('app-bottomnav');
  footerEl = document.getElementById('app-footer');
  mainEl = document.getElementById('app-main');

  window.addEventListener('hashchange', handleRouteChange);
  onAuthChange(() => {
    // Header shows the user's name/avatar — refresh it whenever auth state
    // changes (e.g. profile refresh) without a full route change.
    const path = parseHash();
    const match = matchRoute(path);
    if (match && match.route.shell) {
      renderShell(match.route.navKey);
    }
  });

  if (!window.location.hash) {
    window.location.hash = isAuthenticated() ? '#/dashboard' : '#/login';
  } else {
    handleRouteChange();
  }
}

document.addEventListener('DOMContentLoaded', bootstrap);
