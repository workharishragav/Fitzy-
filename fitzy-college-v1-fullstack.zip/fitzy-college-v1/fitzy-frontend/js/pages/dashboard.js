import { listWorkouts } from '../services/workoutService.js';
import { getUser } from '../state/store.js';
import { renderWorkoutCard } from '../components/workoutCard.js';
import { renderLoading, renderEmptyState, renderErrorBanner } from '../components/states.js';
import { formatNumber } from '../utils/format.js';
import { escapeHtml } from '../utils/dom.js';
import { ApiError } from '../services/apiClient.js';

export async function render(container) {
  const user = getUser();
  const greetingName = user?.name ? user.name.split(' ')[0] : 'there';

  container.innerHTML = `
    <div class="relative w-full max-w-7xl mx-auto px-margin-mobile md:px-margin pt-space-lg pb-space-xl">
      <div class="absolute top-0 right-1/4 w-96 h-96 bg-secondary-fixed-dim/20 rounded-full blur-3xl pointer-events-none -z-10"></div>
      <div class="absolute top-48 left-10 w-80 h-80 bg-primary-fixed-dim/25 rounded-full blur-3xl pointer-events-none -z-10"></div>

      <div class="flex flex-col lg:flex-row lg:items-end justify-between gap-space-lg mb-space-xl">
        <div class="space-y-space-xs">
          <div class="inline-flex items-center gap-space-xs px-2.5 py-1 rounded-full bg-surface-container-high text-primary font-label-sm text-label-sm tracking-wider uppercase">
            <span class="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"></span>
            Fitzy Performance Engine
          </div>
          <h1 class="font-display text-headline-lg md:text-display text-on-surface tracking-tight">
            Good to see you, ${escapeHtml(greetingName)} <span class="inline-block">👋</span>
          </h1>
          <p class="font-body-lg text-body-lg text-on-surface-variant max-w-xl">Here's your fitness activity and AI guidance for today.</p>
        </div>
        <div class="flex flex-wrap sm:flex-nowrap items-center gap-space-sm">
          <a href="#/workouts/new" class="w-full sm:w-auto inline-flex items-center justify-center gap-space-xs px-space-lg py-3.5 rounded-xl bg-primary text-on-primary font-title-sm text-title-sm shadow-lg shadow-primary/20 hover:bg-primary-container active:scale-95 transition-all">
            <span class="material-symbols-outlined text-[20px]" style="font-variation-settings: 'FILL' 1;">add_circle</span>
            <span>Track Workout</span>
          </a>
          <a href="#/ai/insights" class="w-full sm:w-auto inline-flex items-center justify-center gap-space-xs px-space-md py-3.5 rounded-xl bg-surface-container-lowest text-on-surface hover:bg-surface-container transition-all shadow-sm font-label-md text-label-md">
            <span class="material-symbols-outlined text-[20px] text-secondary">trending_up</span>
            <span>Progress &amp; Insights</span>
          </a>
          <a href="#/ai/recommendation" class="w-full sm:w-auto inline-flex items-center justify-center gap-space-xs px-space-md py-3.5 rounded-xl bg-surface-container-low hover:bg-surface-container-high text-primary font-label-md text-label-md transition-all shadow-sm">
            <span class="material-symbols-outlined text-[20px]" style="font-variation-settings: 'FILL' 1;">auto_awesome</span>
            <span>AI Guidance</span>
          </a>
        </div>
      </div>

      <div id="dashboardBody">${renderLoading('Loading your dashboard...')}</div>
    </div>
  `;

  const body = container.querySelector('#dashboardBody');

  let workouts;
  try {
    workouts = await listWorkouts();
  } catch (error) {
    const message = error instanceof ApiError ? error.message : 'Could not load your dashboard.';
    body.innerHTML = renderErrorBanner({ message, retryId: 'dashboardRetry' });
    container.querySelector('#dashboardRetry')?.addEventListener('click', () => render(container));
    return;
  }

  const totalWorkouts = workouts.length;
  const totalDuration = workouts.reduce((sum, w) => sum + (w.duration || 0), 0);
  const totalCalories = workouts.reduce((sum, w) => sum + (w.caloriesBurned || 0), 0);
  const avgDuration = totalWorkouts > 0 ? Math.round(totalDuration / totalWorkouts) : 0;
  const recent = [...workouts]
    .sort((a, b) => new Date(b.workoutDate) - new Date(a.workoutDate))
    .slice(0, 4);

  if (totalWorkouts === 0) {
    body.innerHTML = `
      ${renderMetricCards(0, 0, 0)}
      ${renderAiTeaser()}
      <div class="mt-space-xl">
        ${renderEmptyState({
          icon: 'assignment_add',
          title: 'No workouts yet',
          message: 'Add your first workout to start tracking your progress and unlock AI-powered insights.',
          actionLabel: 'Add Your First Workout',
          actionHref: '#/workouts/new'
        })}
      </div>
    `;
    return;
  }

  body.innerHTML = `
    ${renderMetricCards(totalWorkouts, avgDuration, totalCalories)}
    ${renderAiTeaser()}
    <div class="space-y-space-md">
      <div class="flex items-center justify-between">
        <div>
          <h2 class="font-headline-md text-headline-md text-on-surface">Recent Workouts</h2>
          <p class="font-body-sm text-body-sm text-on-surface-variant">Your most recently logged sessions</p>
        </div>
        <a class="inline-flex items-center gap-1 font-label-md text-label-md text-primary hover:text-primary-container transition-colors" href="#/workouts">
          <span>View All</span>
          <span class="material-symbols-outlined text-[18px]">chevron_right</span>
        </a>
      </div>
      <div class="flex flex-col gap-space-md">
        ${recent.map(renderWorkoutCard).join('')}
      </div>
    </div>
  `;

  container.querySelectorAll('.workout-card').forEach((card) => {
    card.addEventListener('click', () => {
      window.location.hash = `#/workouts/${card.getAttribute('data-workout-id')}`;
    });
  });
}

function renderMetricCards(totalWorkouts, avgDuration, totalCalories) {
  return `
    <div class="grid grid-cols-1 md:grid-cols-3 gap-gutter mb-space-xl">
      <div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between mb-space-md">
          <div class="w-12 h-12 rounded-xl bg-surface-container-low flex items-center justify-center text-primary">
            <span class="material-symbols-outlined text-[26px]">fitness_center</span>
          </div>
        </div>
        <div class="space-y-0.5">
          <p class="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Total Workouts</p>
          <div class="flex items-baseline gap-space-xs">
            <span class="font-display text-metric-val md:text-headline-lg text-on-surface">${formatNumber(totalWorkouts)}</span>
            <span class="font-title-sm text-title-sm text-on-surface-variant">logged</span>
          </div>
        </div>
      </div>

      <div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between mb-space-md">
          <div class="w-12 h-12 rounded-xl bg-surface-container-low flex items-center justify-center text-secondary">
            <span class="material-symbols-outlined text-[26px]">timer</span>
          </div>
        </div>
        <div class="space-y-0.5">
          <p class="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Average Duration</p>
          <div class="flex items-baseline gap-space-xs">
            <span class="font-display text-metric-val md:text-headline-lg text-on-surface">${formatNumber(avgDuration)}</span>
            <span class="font-title-sm text-title-sm text-on-surface-variant">mins / session</span>
          </div>
        </div>
      </div>

      <div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between mb-space-md">
          <div class="w-12 h-12 rounded-xl bg-surface-container-low flex items-center justify-center text-tertiary">
            <span class="material-symbols-outlined text-[26px]">local_fire_department</span>
          </div>
        </div>
        <div class="space-y-0.5">
          <p class="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Calories Burned</p>
          <div class="flex items-baseline gap-space-xs">
            <span class="font-display text-metric-val md:text-headline-lg text-on-surface">${formatNumber(totalCalories)}</span>
            <span class="font-title-sm text-title-sm text-on-surface-variant">kcal</span>
          </div>
        </div>
      </div>
    </div>
  `;
}

function renderAiTeaser() {
  return `
    <div class="relative bg-surface-container-lowest rounded-3xl p-space-lg md:p-space-xl shadow-md overflow-hidden mb-space-xl">
      <div class="absolute inset-0 bg-gradient-to-r from-primary/5 via-secondary/10 to-tertiary/5 pointer-events-none"></div>
      <div class="absolute -top-12 -right-12 w-64 h-64 bg-primary-fixed-dim/30 rounded-full blur-2xl pointer-events-none"></div>
      <div class="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-space-lg">
        <div class="max-w-2xl space-y-space-sm">
          <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary text-on-primary font-label-sm text-label-sm">
            <span class="material-symbols-outlined text-[16px]">auto_awesome</span>
            AI Coach
          </span>
          <h2 class="font-headline-md text-headline-md text-on-surface">✨ Get a Personalized Workout Plan</h2>
          <p class="font-body-lg text-body-lg text-on-surface-variant leading-relaxed">
            Fitzy's AI can generate a full weekly training plan and fitness insights based on your goals and workout history.
          </p>
        </div>
        <div class="flex-shrink-0">
          <a href="#/ai/recommendation" class="w-full lg:w-auto inline-flex items-center justify-center gap-space-xs px-space-lg py-4 rounded-xl bg-primary text-on-primary font-title-sm text-title-sm hover:bg-primary-container shadow-md hover:shadow-lg transition-all">
            <span>Get My Recommendation</span>
            <span class="material-symbols-outlined text-[20px]">arrow_forward</span>
          </a>
        </div>
      </div>
    </div>
  `;
}
