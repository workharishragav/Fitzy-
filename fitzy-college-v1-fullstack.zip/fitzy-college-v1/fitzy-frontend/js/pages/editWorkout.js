import { getWorkout, updateWorkout, deleteWorkout } from '../services/workoutService.js';
import { renderWorkoutForm } from '../components/workoutForm.js';
import { renderLoading, renderErrorBanner } from '../components/states.js';
import { confirmDialog } from '../components/confirmModal.js';
import { showToast } from '../components/toast.js';
import { ApiError } from '../services/apiClient.js';

export async function render(container, params) {
  container.innerHTML = renderLoading('Loading workout...');

  let workout;
  try {
    workout = await getWorkout(params.id);
  } catch (error) {
    const message = error instanceof ApiError ? error.message : 'Could not load this workout.';
    container.innerHTML = `<div class="max-w-3xl mx-auto px-margin-mobile md:px-margin py-space-xl">${renderErrorBanner({ message })}</div>`;
    return;
  }

  renderWorkoutForm(container, {
    heading: 'Edit Workout',
    subheading: 'Update the details of this workout session.',
    submitLabel: 'Save Changes',
    initialData: workout,
    onSubmit: async (payload) => {
      await updateWorkout(workout._id, payload);
      showToast('Workout updated successfully', 'success');
      window.location.hash = `#/workouts/${workout._id}`;
    },
    onDelete: async () => {
      const confirmed = await confirmDialog({
        title: 'Delete Workout?',
        message: `Are you sure you want to delete "${workout.workoutName}"? This action cannot be undone.`,
        confirmLabel: 'Delete Workout'
      });
      if (!confirmed) return;
      try {
        await deleteWorkout(workout._id);
        showToast('Workout deleted', 'success');
        window.location.hash = '#/workouts';
      } catch (error) {
        const message = error instanceof ApiError ? error.message : 'Could not delete this workout.';
        showToast(message, 'error');
      }
    }
  });
}
