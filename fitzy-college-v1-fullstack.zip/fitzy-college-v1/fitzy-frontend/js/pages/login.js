import { login } from '../services/authService.js';
import { ApiError } from '../services/apiClient.js';

export function render(container) {
  container.innerHTML = `
    <div class="relative w-full min-h-screen py-10 lg:py-16 px-gutter-mobile md:px-margin flex items-center justify-center overflow-hidden">
      <div class="absolute -top-24 -left-20 w-96 h-96 rounded-full bg-primary-fixed/20 blur-3xl pointer-events-none"></div>
      <div class="absolute top-1/2 -right-32 w-80 h-80 rounded-full bg-secondary-container/25 blur-3xl pointer-events-none"></div>
      <div class="absolute -bottom-20 left-1/3 w-72 h-72 rounded-full bg-tertiary-fixed-dim/15 blur-2xl pointer-events-none"></div>
      <div class="relative z-10 w-full max-w-md mx-auto">
        <div class="flex flex-col items-center mb-8 text-center">
          <div class="flex items-center gap-2 mb-3 bg-surface-container-lowest px-4 py-2 rounded-full shadow-sm">
            <div class="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-on-primary">
              <span class="material-symbols-outlined text-lg" style="font-variation-settings: 'FILL' 1;">bolt</span>
            </div>
            <span class="font-headline-md text-headline-md tracking-tight text-on-surface">Fitzy <span class="text-primary font-extrabold">AI</span></span>
            <span class="bg-surface-container px-2 py-0.5 rounded text-label-sm font-label-sm text-secondary tracking-wide">COLLEGE V1</span>
          </div>
        </div>

        <div class="bg-surface-container-lowest rounded-xl p-6 sm:p-8 shadow-xl relative">
          <div class="absolute top-0 inset-x-8 h-1 rounded-b-full bg-gradient-to-r from-primary via-secondary to-tertiary"></div>
          <div class="mb-6 pt-2">
            <h1 class="font-headline-lg text-headline-lg text-on-surface">Welcome Back</h1>
            <p class="font-body-md text-body-md text-on-surface-variant mt-1.5">Log in to track your workouts and get AI-powered guidance.</p>
          </div>

          <div class="hidden mb-5 p-3 rounded-lg transition-all duration-200" id="statusAlert">
            <div class="flex items-start gap-2.5">
              <span class="material-symbols-outlined text-xl mt-0.5" id="statusIcon"></span>
              <p class="font-body-sm text-body-sm flex-1" id="statusMsg"></p>
            </div>
          </div>

          <form class="space-y-5" id="loginForm">
            <div class="flex flex-col gap-1.5">
              <label class="font-label-md text-label-md text-on-surface" for="emailInput">Email</label>
              <div class="relative flex items-center">
                <span class="material-symbols-outlined absolute left-3.5 text-outline pointer-events-none text-xl">mail</span>
                <input class="w-full h-12 pl-11 pr-4 rounded-lg bg-surface-container-low text-on-surface font-body-md text-body-md placeholder:text-outline focus:outline-none focus:bg-surface-container-lowest focus:ring-2 focus:ring-primary/20 shadow-sm transition-all" id="emailInput" placeholder="you@example.com" required type="email" autocomplete="email"/>
              </div>
            </div>

            <div class="flex flex-col gap-1.5">
              <label class="font-label-md text-label-md text-on-surface" for="passwordInput">Password</label>
              <div class="relative flex items-center">
                <span class="material-symbols-outlined absolute left-3.5 text-outline pointer-events-none text-xl">lock</span>
                <input class="w-full h-12 pl-11 pr-12 rounded-lg bg-surface-container-low text-on-surface font-body-md text-body-md placeholder:text-outline focus:outline-none focus:bg-surface-container-lowest focus:ring-2 focus:ring-primary/20 shadow-sm transition-all" id="passwordInput" placeholder="Enter password" required type="password" autocomplete="current-password"/>
                <button aria-label="Toggle password visibility" class="absolute right-3 w-8 h-8 flex items-center justify-center text-outline hover:text-on-surface transition rounded" id="togglePasswordBtn" type="button">
                  <span class="material-symbols-outlined text-xl" id="toggleIcon">visibility</span>
                </button>
              </div>
            </div>

            <button class="w-full h-12 rounded-lg bg-primary hover:bg-primary-container text-on-primary font-title-sm text-title-sm flex items-center justify-center gap-2 shadow-md hover:shadow-lg active:scale-[0.99] transition-all disabled:opacity-70 disabled:cursor-not-allowed" id="submitBtn" type="submit">
              <span id="submitBtnLabel">Log In</span>
              <span class="material-symbols-outlined text-xl" id="submitBtnIcon">arrow_forward</span>
            </button>
          </form>

          <div class="mt-6 pt-5 border-t border-surface-container text-center flex flex-col items-center gap-3">
            <p class="font-body-sm text-body-sm text-on-surface-variant">
              Don't have an account yet?
              <a class="font-title-sm text-title-sm text-primary hover:underline ml-1" href="#/register">Create an account</a>
            </p>
          </div>
        </div>

        <div class="mt-6 text-center">
          <p class="font-body-sm text-body-sm text-outline">Fitzy — Personalized Fitness Recommendations Powered by AI</p>
        </div>
      </div>
    </div>
  `;

  const form = container.querySelector('#loginForm');
  const emailInput = container.querySelector('#emailInput');
  const passwordInput = container.querySelector('#passwordInput');
  const toggleBtn = container.querySelector('#togglePasswordBtn');
  const toggleIcon = container.querySelector('#toggleIcon');
  const submitBtn = container.querySelector('#submitBtn');
  const submitBtnLabel = container.querySelector('#submitBtnLabel');
  const submitBtnIcon = container.querySelector('#submitBtnIcon');
  const statusAlert = container.querySelector('#statusAlert');
  const statusIcon = container.querySelector('#statusIcon');
  const statusMsg = container.querySelector('#statusMsg');

  toggleBtn.addEventListener('click', () => {
    const isPassword = passwordInput.type === 'password';
    passwordInput.type = isPassword ? 'text' : 'password';
    toggleIcon.textContent = isPassword ? 'visibility_off' : 'visibility';
  });

  function showAlert(kind, message) {
    const bg = kind === 'error' ? 'bg-error-container' : 'bg-surface-container-high';
    const textColor = kind === 'error' ? 'text-on-error-container' : 'text-on-surface';
    statusAlert.className = `mb-5 p-3 rounded-lg ${bg} ${textColor} block transition-all`;
    statusIcon.className = `material-symbols-outlined text-xl mt-0.5 ${kind === 'error' ? 'text-error' : 'text-primary'}`;
    statusIcon.textContent = kind === 'error' ? 'error' : 'info';
    statusMsg.textContent = message;
  }

  function setLoading(isLoading) {
    submitBtn.disabled = isLoading;
    submitBtnLabel.textContent = isLoading ? 'Logging in...' : 'Log In';
    submitBtnIcon.textContent = isLoading ? '' : 'arrow_forward';
    submitBtnIcon.className = isLoading
      ? 'w-5 h-5 rounded-full border-2 border-white border-t-transparent animate-spin inline-block'
      : 'material-symbols-outlined text-xl';
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = emailInput.value.trim();
    const password = passwordInput.value;

    if (!email || !password) {
      showAlert('error', 'Please enter both email and password.');
      return;
    }

    setLoading(true);
    try {
      await login(email, password);
      window.location.hash = '#/dashboard';
    } catch (error) {
      setLoading(false);
      if (error instanceof ApiError) {
        showAlert('error', error.message);
      } else {
        showAlert('error', 'Something went wrong. Please try again.');
      }
    }
  });
}
