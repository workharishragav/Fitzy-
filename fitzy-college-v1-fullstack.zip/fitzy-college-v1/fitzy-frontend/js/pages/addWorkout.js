import { createWorkout } from '../services/workoutService.js';
import { renderWorkoutForm } from '../components/workoutForm.js';
import { showToast } from '../components/toast.js';

export function render(container) {
  renderWorkoutForm(container, {
    heading: 'Add Workout',
    subheading: 'Record a new workout session to keep your stats and AI recommendations up to date.',
    submitLabel: 'Save Workout',
    onSubmit: async (payload) => {
      const workout = await createWorkout(payload);
      showToast('Workout saved successfully', 'success');
      window.location.hash = `#/workouts/${workout._id}`;
    }
  });
}
