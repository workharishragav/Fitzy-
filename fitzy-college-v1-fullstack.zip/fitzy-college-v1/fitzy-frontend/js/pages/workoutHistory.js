import { listWorkouts } from '../services/workoutService.js';
import { renderWorkoutCard } from '../components/workoutCard.js';
import { renderLoading, renderEmptyState, renderErrorBanner } from '../components/states.js';
import { CATEGORIES } from '../utils/constants.js';
import { escapeHtml } from '../utils/dom.js';
import { ApiError } from '../services/apiClient.js';

let debounceTimer = null;

export function render(container) {
  const categoryPills = ['All', ...CATEGORIES.map((c) => c.value)]
    .map((cat) => {
      const isAll = cat === 'All';
      return `
        <button type="button" data-category-filter="${isAll ? '' : escapeHtml(cat)}"
          class="filter-pill h-9 px-4 rounded-full font-label-sm text-label-sm font-semibold uppercase tracking-wider transition-all flex items-center gap-1.5 ${isAll ? 'bg-primary text-on-primary shadow-sm active-pill' : 'bg-surface-container-low text-on-surface-variant hover:text-on-surface hover:bg-surface-container'}">
          <span>${escapeHtml(cat)}</span>
        </button>
      `;
    })
    .join('');

  container.innerHTML = `
    <div class="max-w-7xl mx-auto px-margin-mobile md:px-margin pt-space-md md:pt-space-lg pb-space-xl flex flex-col gap-space-lg">
      <div class="flex flex-col lg:flex-row lg:items-end justify-between gap-space-md">
        <div class="flex flex-col max-w-xl">
          <span class="font-label-sm text-label-sm uppercase tracking-widest text-primary font-bold mb-space-xs">Training Log</span>
          <h1 class="font-headline-lg text-headline-lg text-on-surface tracking-tight">Workouts</h1>
          <p class="font-body-md text-body-md text-on-surface-variant mt-1">Review your past training sessions and track your consistency.</p>
        </div>
        <a href="#/workouts/new" class="h-12 px-space-lg bg-primary hover:bg-primary-container text-on-primary font-label-md text-label-md rounded-xl shadow-md flex items-center justify-center gap-2 transition-all active:scale-[0.98] self-start lg:self-auto">
          <span class="material-symbols-outlined text-[20px]">add</span>
          <span>Add Workout</span>
        </a>
      </div>

      <div class="flex flex-col gap-space-md bg-surface-container-lowest p-space-md md:p-space-lg rounded-2xl shadow-sm">
        <div class="flex flex-col md:flex-row md:items-center gap-space-md">
          <div class="relative flex-1">
            <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-on-surface-variant">
              <span class="material-symbols-outlined text-[20px]">search</span>
            </div>
            <input id="searchInput" class="w-full h-12 pl-10 pr-10 rounded-xl bg-surface-container-low font-body-md text-body-md text-on-surface placeholder:text-on-surface-variant/70 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:bg-surface-container-lowest transition-all" placeholder="Search workouts by name..." type="text"/>
          </div>
          <div class="relative">
            <input id="dateInput" class="h-12 pl-4 pr-4 rounded-xl bg-surface-container-low font-body-md text-body-md text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20 focus:bg-surface-container-lowest transition-all cursor-pointer" type="date"/>
          </div>
          <button id="clearFiltersBtn" type="button" class="h-12 px-space-md rounded-xl bg-surface-container-low text-on-surface-variant hover:text-on-surface hover:bg-surface-container font-label-md text-label-md transition-all hidden">
            Clear
          </button>
        </div>
        <div class="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar" id="categoryPills">
          ${categoryPills}
        </div>
      </div>

      <div id="workoutsListBody">${renderLoading('Loading your workouts...')}</div>
    </div>
  `;

  const state = { search: '', category: '', date: '' };
  const searchInput = container.querySelector('#searchInput');
  const dateInput = container.querySelector('#dateInput');
  const categoryPillsEl = container.querySelector('#categoryPills');
  const clearBtn = container.querySelector('#clearFiltersBtn');
  const listBody = container.querySelector('#workoutsListBody');

  function updateClearButton() {
    const hasFilters = state.search || state.category || state.date;
    clearBtn.classList.toggle('hidden', !hasFilters);
  }

  async function refresh() {
    listBody.innerHTML = renderLoading('Loading your workouts...');
    let workouts;
    try {
      workouts = await listWorkouts(state);
    } catch (error) {
      const message = error instanceof ApiError ? error.message : 'Could not load your workouts.';
      listBody.innerHTML = renderErrorBanner({ message, retryId: 'workoutsRetry' });
      container.querySelector('#workoutsRetry')?.addEventListener('click', refresh);
      return;
    }

    if (workouts.length === 0) {
      const hasFilters = state.search || state.category || state.date;
      listBody.innerHTML = renderEmptyState({
        icon: hasFilters ? 'search_off' : 'assignment_add',
        title: hasFilters ? 'No matching workouts' : 'No workouts yet',
        message: hasFilters
          ? 'Try a different search term, category, or date.'
          : 'Add your first workout to start tracking your progress.',
        actionLabel: hasFilters ? undefined : 'Add Your First Workout',
        actionHref: hasFilters ? undefined : '#/workouts/new'
      });
      return;
    }

    listBody.innerHTML = `<div class="flex flex-col gap-space-md">${workouts.map(renderWorkoutCard).join('')}</div>`;
    listBody.querySelectorAll('.workout-card').forEach((card) => {
      card.addEventListener('click', () => {
        window.location.hash = `#/workouts/${card.getAttribute('data-workout-id')}`;
      });
    });
  }

  searchInput.addEventListener('input', (e) => {
    state.search = e.target.value.trim();
    updateClearButton();
    if (debounceTimer) clearTimeout(debounceTimer);
    debounceTimer = setTimeout(refresh, 350);
  });

  dateInput.addEventListener('change', (e) => {
    state.date = e.target.value;
    updateClearButton();
    refresh();
  });

  categoryPillsEl.addEventListener('click', (e) => {
    const pill = e.target.closest('[data-category-filter]');
    if (!pill) return;
    state.category = pill.getAttribute('data-category-filter');
    categoryPillsEl.querySelectorAll('.filter-pill').forEach((p) => {
      const isActive = p === pill;
      p.className = `filter-pill h-9 px-4 rounded-full font-label-sm text-label-sm font-semibold uppercase tracking-wider transition-all flex items-center gap-1.5 ${isActive ? 'bg-primary text-on-primary shadow-sm active-pill' : 'bg-surface-container-low text-on-surface-variant hover:text-on-surface hover:bg-surface-container'}`;
    });
    updateClearButton();
    refresh();
  });

  clearBtn.addEventListener('click', () => {
    state.search = '';
    state.category = '';
    state.date = '';
    searchInput.value = '';
    dateInput.value = '';
    categoryPillsEl.querySelectorAll('.filter-pill').forEach((p, idx) => {
      const isAll = idx === 0;
      p.className = `filter-pill h-9 px-4 rounded-full font-label-sm text-label-sm font-semibold uppercase tracking-wider transition-all flex items-center gap-1.5 ${isAll ? 'bg-primary text-on-primary shadow-sm active-pill' : 'bg-surface-container-low text-on-surface-variant hover:text-on-surface hover:bg-surface-container'}`;
    });
    updateClearButton();
    refresh();
  });

  refresh();
}
