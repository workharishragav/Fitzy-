import { getWorkout, deleteWorkout } from '../services/workoutService.js';
import { renderLoading, renderErrorBanner } from '../components/states.js';
import { confirmDialog } from '../components/confirmModal.js';
import { showToast } from '../components/toast.js';
import { categoryMeta } from '../utils/constants.js';
import { formatDate, formatNumber } from '../utils/format.js';
import { escapeHtml } from '../utils/dom.js';
import { ApiError } from '../services/apiClient.js';

export async function render(container, params) {
  container.innerHTML = `<div class="max-w-7xl mx-auto px-margin-mobile md:px-margin py-space-xl">${renderLoading('Loading workout...')}</div>`;

  let workout;
  try {
    workout = await getWorkout(params.id);
  } catch (error) {
    const message = error instanceof ApiError ? error.message : 'Could not load this workout.';
    container.innerHTML = `
      <div class="max-w-3xl mx-auto px-margin-mobile md:px-margin py-space-xl flex flex-col gap-space-md">
        ${renderErrorBanner({ message })}
        <a href="#/workouts" class="inline-flex items-center gap-space-xs font-label-md text-label-md text-primary hover:text-primary-container transition-colors">
          <span class="material-symbols-outlined text-[18px]">arrow_back</span>
          <span>Back to Workouts</span>
        </a>
      </div>
    `;
    return;
  }

  const meta = categoryMeta(workout.category);

  container.innerHTML = `
    <div class="max-w-7xl mx-auto px-margin-mobile md:px-margin w-full pt-space-lg pb-space-sm flex flex-col md:flex-row md:items-center justify-between gap-space-md">
      <a href="#/workouts" class="inline-flex items-center gap-space-xs font-label-md text-label-md text-primary hover:text-primary-container transition-colors py-space-xs px-space-sm rounded-lg hover:bg-surface-container-low">
        <span class="material-symbols-outlined text-[18px]">arrow_back</span>
        <span>Back to Workouts</span>
      </a>
      <div class="flex items-center gap-space-sm">
        <a href="#/workouts/${escapeHtml(workout._id)}/edit" class="inline-flex items-center gap-space-xs px-space-md py-space-xs bg-surface-container-lowest text-on-surface font-label-md text-label-md rounded-lg shadow-sm hover:bg-surface-container transition-all">
          <span class="material-symbols-outlined text-[18px] text-on-surface-variant">edit</span>
          <span>Edit</span>
        </a>
        <button type="button" id="deleteBtn" class="inline-flex items-center gap-space-xs px-space-md py-space-xs bg-error-container text-on-error-container font-label-md text-label-md rounded-lg shadow-sm hover:opacity-90 transition-all">
          <span class="material-symbols-outlined text-[18px]">delete</span>
          <span>Delete</span>
        </button>
      </div>
    </div>

    <div class="max-w-7xl mx-auto px-margin-mobile md:px-margin w-full pb-space-xl">
      <div class="relative overflow-hidden bg-surface-container-lowest rounded-xl p-space-lg shadow-sm">
        <div class="absolute -right-16 -top-16 w-64 h-64 bg-${meta.color}-fixed/20 rounded-full blur-3xl pointer-events-none"></div>
        <div class="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-space-md">
          <div>
            <div class="flex items-center gap-space-xs mb-space-xs">
              <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-${meta.color}-fixed text-on-${meta.color}-fixed font-label-sm text-label-sm">
                <span class="w-1.5 h-1.5 rounded-full bg-${meta.color}"></span>
                ${escapeHtml(workout.category)}
              </span>
            </div>
            <h1 class="font-headline-lg text-headline-lg text-on-surface tracking-tight">${escapeHtml(workout.workoutName)}</h1>
            <p class="font-body-md text-body-md text-on-surface-variant mt-1 flex items-center gap-space-xs">
              <span class="material-symbols-outlined text-[18px] text-primary">event</span>
              <span>${formatDate(workout.workoutDate)}</span>
            </p>
          </div>
          <div class="w-16 h-16 rounded-2xl bg-${meta.color}-container/10 flex items-center justify-center text-${meta.color} shrink-0">
            <span class="material-symbols-outlined text-[32px]">${meta.icon}</span>
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-space-md mt-space-lg pt-space-md bg-surface-container-low/60 rounded-lg p-space-md">
          <div class="flex items-start gap-space-sm">
            <div class="w-10 h-10 rounded-lg bg-surface-container-lowest flex items-center justify-center text-primary shadow-sm">
              <span class="material-symbols-outlined text-[24px]">schedule</span>
            </div>
            <div>
              <span class="font-label-sm text-label-sm text-on-surface-variant block uppercase tracking-wider">Duration</span>
              <span class="font-metric-val text-metric-val text-on-surface">${formatNumber(workout.duration)}</span>
              <span class="font-label-md text-label-md text-on-surface-variant">min</span>
            </div>
          </div>
          <div class="flex items-start gap-space-sm">
            <div class="w-10 h-10 rounded-lg bg-surface-container-lowest flex items-center justify-center text-tertiary shadow-sm">
              <span class="material-symbols-outlined text-[24px]">local_fire_department</span>
            </div>
            <div>
              <span class="font-label-sm text-label-sm text-on-surface-variant block uppercase tracking-wider">Calories Burned</span>
              <span class="font-metric-val text-metric-val text-on-surface">${formatNumber(workout.caloriesBurned)}</span>
              <span class="font-label-md text-label-md text-on-surface-variant">kcal</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;

  container.querySelector('#deleteBtn').addEventListener('click', async () => {
    const confirmed = await confirmDialog({
      title: 'Delete Workout?',
      message: `Are you sure you want to delete "${workout.workoutName}"? This action cannot be undone.`,
      confirmLabel: 'Delete Workout'
    });
    if (!confirmed) return;
    try {
      await deleteWorkout(workout._id);
      showToast('Workout deleted', 'success');
      window.location.hash = '#/workouts';
    } catch (error) {
      const message = error instanceof ApiError ? error.message : 'Could not delete this workout.';
      showToast(message, 'error');
    }
  });
}
