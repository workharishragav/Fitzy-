import { listWorkouts } from '../services/workoutService.js';
import { getInsights } from '../services/aiService.js';
import { renderLoading, renderEmptyState, renderErrorBanner } from '../components/states.js';
import { formatNumber } from '../utils/format.js';
import { escapeHtml } from '../utils/dom.js';
import { ApiError } from '../services/apiClient.js';

export async function render(container) {
  container.innerHTML = `
    <div class="max-w-7xl mx-auto w-full px-margin-mobile md:px-margin py-space-md md:py-space-lg space-y-space-lg">
      <div class="flex flex-col md:flex-row md:items-end justify-between gap-space-md">
        <div class="space-y-space-xs">
          <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-secondary-container text-on-secondary-container font-label-sm text-label-sm">
            <span class="material-symbols-outlined text-[14px]" style="font-variation-settings: 'FILL' 1;">auto_awesome</span> Fitzy AI Coach
          </span>
          <h1 class="font-headline-lg text-headline-lg text-on-surface tracking-tight">Fitness Insights</h1>
          <p class="font-body-lg text-body-lg text-on-surface-variant max-w-2xl mt-1">AI-driven analysis of your logged workout activity.</p>
        </div>
      </div>
      <div id="insightsBody">${renderLoading('Loading your workout data...')}</div>
    </div>
  `;

  const body = container.querySelector('#insightsBody');

  let workouts;
  try {
    workouts = await listWorkouts();
  } catch (error) {
    const message = error instanceof ApiError ? error.message : 'Could not load your workout data.';
    body.innerHTML = renderErrorBanner({ message, retryId: 'insightsRetry' });
    container.querySelector('#insightsRetry')?.addEventListener('click', () => render(container));
    return;
  }

  if (workouts.length === 0) {
    body.innerHTML = renderEmptyState({
      icon: 'insights',
      title: 'No workout data yet',
      message: 'Log a few workouts first — Fitzy\'s AI needs some activity to analyze before it can generate insights.',
      actionLabel: 'Add a Workout',
      actionHref: '#/workouts/new'
    });
    return;
  }

  const totalWorkouts = workouts.length;
  const totalDuration = workouts.reduce((sum, w) => sum + (w.duration || 0), 0);
  const totalCaloriesBurned = workouts.reduce((sum, w) => sum + (w.caloriesBurned || 0), 0);
  const averageWorkoutDuration = Math.round(totalDuration / totalWorkouts);

  body.innerHTML = `
    <div class="grid grid-cols-1 md:grid-cols-3 gap-gutter">
      ${statCard('fitness_center', 'primary', 'Total Workouts', `${formatNumber(totalWorkouts)} sessions`)}
      ${statCard('timer', 'secondary', 'Avg Workout Duration', `${formatNumber(averageWorkoutDuration)} mins`)}
      ${statCard('local_fire_department', 'tertiary', 'Total Calories Burned', `${formatNumber(totalCaloriesBurned)} kcal`)}
    </div>
    <div class="flex justify-center md:justify-end">
      <button type="button" id="analyzeBtn" class="group relative inline-flex items-center justify-center gap-2 px-space-lg py-3 rounded-xl bg-gradient-to-r from-primary to-secondary text-on-primary font-label-md text-label-md shadow-md hover:shadow-lg transition-all active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed">
        <span class="material-symbols-outlined text-[20px]" id="analyzeBtnIcon" style="font-variation-settings: 'FILL' 1;">neurology</span>
        <span id="analyzeBtnLabel">Analyze My Progress</span>
      </button>
    </div>
    <div id="insightsResult"></div>
  `;

  const analyzeBtn = body.querySelector('#analyzeBtn');
  const analyzeBtnLabel = body.querySelector('#analyzeBtnLabel');
  const analyzeBtnIcon = body.querySelector('#analyzeBtnIcon');
  const resultEl = body.querySelector('#insightsResult');

  function setLoading(isLoading) {
    analyzeBtn.disabled = isLoading;
    analyzeBtnLabel.textContent = isLoading ? 'Analyzing...' : 'Analyze My Progress';
    analyzeBtnIcon.className = isLoading
      ? 'w-4 h-4 rounded-full border-2 border-white border-t-transparent animate-spin inline-block'
      : "material-symbols-outlined text-[20px]";
    if (!isLoading) analyzeBtnIcon.setAttribute('style', "font-variation-settings: 'FILL' 1;");
  }

  async function runAnalysis() {
    setLoading(true);
    resultEl.innerHTML = renderLoading('Fitzy\'s AI is analyzing your progress...');
    try {
      const data = await getInsights({ totalWorkouts, averageWorkoutDuration, totalCaloriesBurned });
      resultEl.innerHTML = renderInsights(data);
    } catch (error) {
      const message = error instanceof ApiError ? error.message : 'Something went wrong generating your insights.';
      resultEl.innerHTML = renderErrorBanner({ title: "Couldn't generate insights", message, retryId: 'insightsAnalyzeRetry' });
      resultEl.querySelector('#insightsAnalyzeRetry')?.addEventListener('click', runAnalysis);
    } finally {
      setLoading(false);
    }
  }

  analyzeBtn.addEventListener('click', runAnalysis);
}

function statCard(icon, color, label, value) {
  return `
    <div class="relative overflow-hidden rounded-xl bg-surface-container-lowest p-space-lg shadow-sm hover:shadow-md transition-shadow">
      <div class="flex items-start justify-between">
        <div class="flex flex-col">
          <span class="font-label-md text-label-md text-on-surface-variant uppercase tracking-wider">${escapeHtml(label)}</span>
          <span class="font-metric-val text-metric-val text-on-surface mt-1">${escapeHtml(value)}</span>
        </div>
        <div class="w-10 h-10 rounded-lg bg-surface-container-low flex items-center justify-center text-${color}">
          <span class="material-symbols-outlined text-[22px]">${icon}</span>
        </div>
      </div>
    </div>
  `;
}

function renderInsights(data) {
  const performanceAnalysis = typeof data?.performanceAnalysis === 'string' ? data.performanceAnalysis : '';
  const improvementSuggestions = Array.isArray(data?.improvementSuggestions) ? data.improvementSuggestions : [];
  const motivationalAdvice = typeof data?.motivationalAdvice === 'string' ? data.motivationalAdvice : '';
  const progressSummary = typeof data?.progressSummary === 'string' ? data.progressSummary : '';
  const disclaimer = typeof data?.disclaimer === 'string' ? data.disclaimer : '';

  return `
    <div class="space-y-space-lg mt-space-md">
      ${progressSummary ? `
      <div class="rounded-3xl bg-surface-container-lowest p-space-lg shadow-sm space-y-space-sm">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-xl bg-primary-fixed/40 text-primary flex items-center justify-center">
            <span class="material-symbols-outlined text-[22px]">summarize</span>
          </div>
          <h2 class="font-headline-md text-headline-md text-on-surface">Progress Summary</h2>
        </div>
        <p class="font-body-lg text-body-lg text-on-surface-variant leading-relaxed">${escapeHtml(progressSummary)}</p>
      </div>` : ''}

      <div class="grid grid-cols-1 md:grid-cols-2 gap-gutter">
        ${performanceAnalysis ? `
        <div class="rounded-2xl bg-surface-container-lowest p-space-lg shadow-sm flex flex-col gap-space-sm">
          <div class="flex items-center gap-space-xs">
            <div class="w-8 h-8 rounded-lg bg-surface-container-low text-primary flex items-center justify-center">
              <span class="material-symbols-outlined text-[20px]">insights</span>
            </div>
            <span class="font-headline-md text-headline-md text-on-surface">Performance Analysis</span>
          </div>
          <p class="font-body-md text-body-md text-on-surface-variant leading-relaxed">${escapeHtml(performanceAnalysis)}</p>
        </div>` : ''}

        ${improvementSuggestions.length ? `
        <div class="rounded-2xl bg-surface-container-lowest p-space-lg shadow-sm flex flex-col gap-space-sm">
          <div class="flex items-center gap-space-xs">
            <div class="w-8 h-8 rounded-lg bg-error-container text-error flex items-center justify-center">
              <span class="material-symbols-outlined text-[20px]">priority_high</span>
            </div>
            <span class="font-headline-md text-headline-md text-on-surface">Areas to Improve</span>
          </div>
          <div class="space-y-2">
            ${improvementSuggestions.map((s) => `
              <div class="flex items-start gap-space-sm p-space-md rounded-xl bg-surface-container-low">
                <span class="material-symbols-outlined text-error mt-0.5 text-[18px] shrink-0">arrow_upward</span>
                <p class="font-body-md text-body-md text-on-surface-variant">${escapeHtml(s)}</p>
              </div>
            `).join('')}
          </div>
        </div>` : ''}
      </div>

      ${motivationalAdvice ? `
      <div class="rounded-2xl bg-surface-container-high p-space-lg shadow-sm relative overflow-hidden">
        <div class="flex items-start gap-space-sm">
          <div class="w-10 h-10 rounded-xl bg-tertiary-container text-on-tertiary-container shrink-0 flex items-center justify-center">
            <span class="material-symbols-outlined text-[20px]" style="font-variation-settings: 'FILL' 1;">military_tech</span>
          </div>
          <div>
            <span class="font-label-sm text-label-sm text-tertiary font-bold uppercase tracking-wider">Motivation</span>
            <p class="font-body-md text-body-md text-on-surface-variant mt-1 leading-relaxed italic">"${escapeHtml(motivationalAdvice)}"</p>
          </div>
        </div>
      </div>` : ''}

      <div class="flex items-start gap-2 px-space-md py-space-sm rounded-xl bg-surface-container-low text-on-surface-variant">
        <span class="material-symbols-outlined text-[16px] mt-0.5 shrink-0">info</span>
        <p class="font-body-sm text-body-sm">${escapeHtml(disclaimer || 'This is general fitness guidance generated by AI, not medical advice. Consult a healthcare professional for any health concerns.')}</p>
      </div>
    </div>
  `;
}
