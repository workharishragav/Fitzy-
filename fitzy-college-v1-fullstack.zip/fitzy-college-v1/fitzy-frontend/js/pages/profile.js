import { refreshProfile, logout } from '../services/authService.js';
import { renderLoading, renderErrorBanner } from '../components/states.js';
import { showToast } from '../components/toast.js';
import { escapeHtml } from '../utils/dom.js';
import { ApiError } from '../services/apiClient.js';

function initials(name) {
  if (!name) return 'FZ';
  const parts = name.trim().split(/\s+/);
  const first = parts[0]?.[0] || '';
  const last = parts.length > 1 ? parts[parts.length - 1][0] : '';
  return (first + last).toUpperCase() || 'FZ';
}

export async function render(container) {
  container.innerHTML = `<div class="max-w-7xl mx-auto px-margin-mobile md:px-margin py-space-xl">${renderLoading('Loading your profile...')}</div>`;

  let user;
  try {
    user = await refreshProfile();
  } catch (error) {
    const message = error instanceof ApiError ? error.message : 'Could not load your profile.';
    container.innerHTML = `<div class="max-w-3xl mx-auto px-margin-mobile md:px-margin py-space-xl">${renderErrorBanner({ message })}</div>`;
    return;
  }

  container.innerHTML = `
    <div class="max-w-7xl mx-auto px-margin w-full py-space-xl">
      <div class="flex flex-col md:flex-row md:items-end justify-between gap-space-md mb-space-xl">
        <div>
          <span class="font-label-sm text-label-sm text-primary uppercase tracking-wider">Your Profile</span>
          <h1 class="font-headline-lg text-headline-lg text-on-surface tracking-tight">Profile</h1>
          <p class="font-body-lg text-body-lg text-on-surface-variant mt-1 max-w-2xl">Manage your account details.</p>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-gutter items-start">
        <div class="lg:col-span-4 flex flex-col gap-gutter">
          <div class="bg-surface-container-lowest rounded-2xl shadow-sm overflow-hidden relative">
            <div class="h-24 bg-gradient-to-tr from-primary-container via-primary to-secondary relative overflow-hidden">
              <div class="absolute inset-0 opacity-15 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:12px_12px]"></div>
            </div>
            <div class="px-space-lg pb-space-lg relative flex flex-col items-center text-center">
              <div class="-mt-10 relative">
                <div class="w-20 h-20 rounded-2xl bg-surface-container-lowest shadow-md flex items-center justify-center">
                  <span class="w-16 h-16 rounded-xl bg-primary-container text-on-primary-container flex items-center justify-center font-headline-md text-headline-md font-bold">${escapeHtml(initials(user.name))}</span>
                </div>
              </div>
              <div class="mt-4">
                <h2 class="font-headline-md text-headline-md text-on-surface">${escapeHtml(user.name || '')}</h2>
                <p class="font-body-md text-body-md text-on-surface-variant mt-0.5">${escapeHtml(user.email || '')}</p>
              </div>
              <div class="mt-4 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-surface-container text-on-surface font-label-md text-label-md">
                <span class="material-symbols-outlined text-primary text-[18px]">school</span>
                <span>Fitzy College V1</span>
              </div>
            </div>
          </div>
        </div>

        <div class="lg:col-span-8 flex flex-col gap-gutter">
          <div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm pb-space-md">
              <div>
                <span class="font-label-sm text-label-sm uppercase tracking-wider text-primary font-bold">Account Details</span>
                <h3 class="font-headline-md text-headline-md text-on-surface mt-0.5">Your Information</h3>
              </div>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-space-md mt-space-lg">
              <div class="bg-surface-container-low/70 rounded-xl p-space-md flex flex-col justify-between">
                <span class="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Full Name</span>
                <div class="flex items-center justify-between mt-2">
                  <span class="font-title-sm text-title-sm text-on-surface font-semibold">${escapeHtml(user.name || '—')}</span>
                  <span class="material-symbols-outlined text-outline text-[20px]">badge</span>
                </div>
              </div>
              <div class="bg-surface-container-low/70 rounded-xl p-space-md flex flex-col justify-between">
                <span class="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Email</span>
                <div class="flex items-center justify-between gap-2 mt-2">
                  <span class="font-title-sm text-title-sm text-on-surface font-semibold truncate">${escapeHtml(user.email || '—')}</span>
                  <span class="material-symbols-outlined text-outline text-[20px] shrink-0">mail</span>
                </div>
              </div>
              <div class="bg-surface-container-low/70 rounded-xl p-space-md flex flex-col justify-between">
                <span class="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Age</span>
                <div class="flex items-center justify-between mt-2">
                  <span class="font-title-sm text-title-sm text-on-surface font-semibold">${user.age ? `${escapeHtml(String(user.age))} yrs` : 'Not set'}</span>
                  <span class="material-symbols-outlined text-outline text-[20px]">cake</span>
                </div>
              </div>
              <div class="bg-surface-container-low/70 rounded-xl p-space-md flex flex-col justify-between">
                <span class="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Fitness Goal</span>
                <div class="mt-2 flex items-center">
                  ${user.fitnessGoal
                    ? `<span class="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-primary-container text-on-primary-container font-label-md text-label-md">
                         <span class="material-symbols-outlined text-[18px]">fitness_center</span>
                         <span>${escapeHtml(user.fitnessGoal)}</span>
                       </span>`
                    : '<span class="font-title-sm text-title-sm text-on-surface-variant">Not set</span>'}
                </div>
              </div>
              <div class="bg-surface-container-low/70 rounded-xl p-space-md flex flex-col justify-between sm:col-span-2">
                <span class="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Experience Level</span>
                <div class="mt-2 flex items-center">
                  ${user.experienceLevel
                    ? `<span class="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-secondary-container text-on-secondary-container font-label-md text-label-md">
                         <span class="material-symbols-outlined text-[18px]">speed</span>
                         <span>${escapeHtml(user.experienceLevel)}</span>
                       </span>`
                    : '<span class="font-title-sm text-title-sm text-on-surface-variant">Not set</span>'}
                </div>
              </div>
            </div>
          </div>

          <div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm">
            <button type="button" id="logoutBtn" class="w-full inline-flex items-center justify-center gap-2 px-space-lg py-3 rounded-xl bg-surface-container-low text-error font-label-md text-label-md hover:bg-error-container hover:text-on-error-container active:scale-[0.99] transition-all">
              <span class="material-symbols-outlined text-[20px]">logout</span>
              <span>Logout</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  `;

  container.querySelector('#logoutBtn').addEventListener('click', () => {
    logout();
    showToast('Logged out successfully', 'info');
    window.location.hash = '#/login';
  });
}
