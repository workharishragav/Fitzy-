import { register } from '../services/authService.js';
import { ApiError } from '../services/apiClient.js';
import { FITNESS_GOALS, EXPERIENCE_LEVELS } from '../utils/constants.js';
import { escapeHtml } from '../utils/dom.js';

const DEFAULT_GOAL = 'Muscle Gain';
const DEFAULT_EXPERIENCE = 'Beginner';

export function render(container) {
  const goalCards = FITNESS_GOALS.map((goal) => {
    const selected = goal.value === DEFAULT_GOAL;
    return `
      <button type="button" data-goal="${escapeHtml(goal.value)}" aria-checked="${selected}" role="radio"
        class="goal-card text-left p-3.5 rounded-xl transition-all flex flex-col justify-between h-24 focus:outline-none ${selected ? 'bg-primary text-on-primary shadow-md' : 'bg-surface-container hover:bg-surface-container-high'}">
        <div class="w-8 h-8 rounded-lg flex items-center justify-center ${selected ? 'bg-surface-container-lowest/20 text-on-primary' : 'bg-surface-container-lowest text-outline'}">
          <span class="material-symbols-outlined text-xl">${goal.icon}</span>
        </div>
        <div>
          <div class="font-title-sm text-title-sm ${selected ? 'text-on-primary font-bold' : 'text-on-surface'}">${escapeHtml(goal.value)}</div>
          <div class="font-label-sm text-xs ${selected ? 'text-primary-fixed' : 'text-outline'}">${escapeHtml(goal.subtitle)}</div>
        </div>
      </button>
    `;
  }).join('');

  const experienceCards = EXPERIENCE_LEVELS.map((level) => {
    const selected = level.value === DEFAULT_EXPERIENCE;
    return `
      <div data-experience="${escapeHtml(level.value)}" role="radio" aria-checked="${selected}" tabindex="0"
        class="exp-card cursor-pointer p-4 rounded-xl transition-all flex flex-col justify-between ${selected ? 'bg-primary/10 shadow-sm' : 'bg-surface-container hover:bg-surface-container-high'}">
        <div class="flex items-center justify-between mb-2">
          <span class="font-title-sm text-title-sm ${selected ? 'text-primary font-bold' : 'text-on-surface'}">${escapeHtml(level.value)}</span>
          <span class="radio-indicator w-5 h-5 rounded-full flex items-center justify-center ${selected ? 'bg-primary' : 'bg-surface-container-highest'}">
            ${selected ? '<span class="w-2 h-2 rounded-full bg-on-primary"></span>' : ''}
          </span>
        </div>
        <p class="font-body-sm text-body-sm ${selected ? 'text-on-surface-variant font-medium' : 'text-outline'}">${escapeHtml(level.subtitle)}</p>
      </div>
    `;
  }).join('');

  container.innerHTML = `
    <div class="w-full min-h-screen flex items-center py-8 sm:py-12 px-gutter-mobile md:px-margin">
      <div class="flex flex-col w-full max-w-3xl mx-auto">
        <div class="flex flex-col items-center mb-6 text-center">
          <div class="flex items-center gap-2 mb-3 bg-surface-container-lowest px-4 py-2 rounded-full shadow-sm">
            <div class="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-on-primary">
              <span class="material-symbols-outlined text-lg" style="font-variation-settings: 'FILL' 1;">bolt</span>
            </div>
            <span class="font-headline-md text-headline-md tracking-tight text-on-surface">Fitzy <span class="text-primary font-extrabold">AI</span></span>
          </div>
          <h1 class="font-headline-lg text-headline-lg text-on-surface tracking-tight">Create your Fitzy account</h1>
          <p class="font-body-md text-body-md text-on-surface-variant mt-1.5 max-w-lg">Start your fitness journey with personalized AI guidance and workout tracking.</p>
        </div>

        <div class="bg-surface-container-lowest rounded-xl shadow-md p-6 sm:p-8 md:p-10">
          <div class="hidden mb-5 p-3 rounded-lg transition-all duration-200" id="statusAlert">
            <div class="flex items-start gap-2.5">
              <span class="material-symbols-outlined text-xl mt-0.5" id="statusIcon"></span>
              <p class="font-body-sm text-body-sm flex-1" id="statusMsg"></p>
            </div>
          </div>

          <form class="space-y-6" id="registerForm">
            <div>
              <h2 class="font-label-md text-label-md uppercase tracking-wider text-outline mb-4 flex items-center gap-2">
                <span class="w-1.5 h-1.5 rounded-full bg-primary"></span> Personal Profile
              </h2>
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="space-y-1.5">
                  <label class="block font-label-md text-label-md text-on-surface" for="fullName">Full Name</label>
                  <div class="relative">
                    <span class="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-outline text-xl pointer-events-none">person</span>
                    <input class="w-full h-12 pl-11 pr-4 bg-surface-container-low text-on-surface font-body-md text-body-md rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/40 focus:bg-surface-container-lowest transition-all" id="fullName" placeholder="e.g. Alex Morgan" required type="text"/>
                  </div>
                </div>
                <div class="space-y-1.5">
                  <label class="block font-label-md text-label-md text-on-surface" for="age">Age</label>
                  <div class="relative">
                    <span class="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-outline text-xl pointer-events-none">calendar_today</span>
                    <input class="w-full h-12 pl-11 pr-4 bg-surface-container-low text-on-surface font-body-md text-body-md rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/40 focus:bg-surface-container-lowest transition-all" id="age" max="99" min="10" placeholder="20" type="number"/>
                  </div>
                  <p class="font-body-sm text-body-sm text-outline">Optional — used to personalize AI recommendations.</p>
                </div>
              </div>
              <div class="mt-4 space-y-1.5">
                <label class="block font-label-md text-label-md text-on-surface" for="email">Email</label>
                <div class="relative">
                  <span class="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-outline text-xl pointer-events-none">mail</span>
                  <input class="w-full h-12 pl-11 pr-4 bg-surface-container-low text-on-surface font-body-md text-body-md rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/40 focus:bg-surface-container-lowest transition-all" id="email" placeholder="you@example.com" required type="email" autocomplete="email"/>
                </div>
              </div>
            </div>

            <div class="pt-2">
              <h2 class="font-label-md text-label-md uppercase tracking-wider text-outline mb-4 flex items-center gap-2">
                <span class="w-1.5 h-1.5 rounded-full bg-primary"></span> Security
              </h2>
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="space-y-1.5">
                  <label class="block font-label-md text-label-md text-on-surface" for="password">Password</label>
                  <div class="relative">
                    <span class="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-outline text-xl pointer-events-none">lock</span>
                    <input class="w-full h-12 pl-11 pr-10 bg-surface-container-low text-on-surface font-body-md text-body-md rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/40 focus:bg-surface-container-lowest transition-all" id="password" required type="password" minlength="6" autocomplete="new-password"/>
                    <button class="absolute right-3 top-1/2 -translate-y-1/2 text-outline hover:text-on-surface focus:outline-none" id="togglePassword" type="button">
                      <span class="material-symbols-outlined text-lg">visibility</span>
                    </button>
                  </div>
                  <p class="font-body-sm text-body-sm text-outline">At least 6 characters.</p>
                </div>
                <div class="space-y-1.5">
                  <label class="block font-label-md text-label-md text-on-surface" for="confirmPassword">Confirm Password</label>
                  <div class="relative">
                    <span class="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-outline text-xl pointer-events-none">verified_user</span>
                    <input class="w-full h-12 pl-11 pr-10 bg-surface-container-low text-on-surface font-body-md text-body-md rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/40 focus:bg-surface-container-lowest transition-all" id="confirmPassword" required type="password" autocomplete="new-password"/>
                  </div>
                </div>
              </div>
            </div>

            <div class="pt-2">
              <label class="font-label-md text-label-md uppercase tracking-wider text-outline flex items-center gap-2 mb-3">
                <span class="w-1.5 h-1.5 rounded-full bg-primary"></span> Primary Fitness Goal
              </label>
              <div aria-label="Fitness Goal" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3" id="goalGroup" role="radiogroup">
                ${goalCards}
              </div>
              <input type="hidden" id="selectedGoal" value="${escapeHtml(DEFAULT_GOAL)}"/>
            </div>

            <div class="pt-2">
              <label class="font-label-md text-label-md uppercase tracking-wider text-outline flex items-center gap-2 mb-3">
                <span class="w-1.5 h-1.5 rounded-full bg-primary"></span> Experience Level
              </label>
              <div class="grid grid-cols-1 sm:grid-cols-3 gap-3" id="experienceGroup">
                ${experienceCards}
              </div>
              <input type="hidden" id="selectedExperience" value="${escapeHtml(DEFAULT_EXPERIENCE)}"/>
            </div>

            <div class="pt-4 flex flex-col gap-3">
              <button class="w-full h-12 bg-primary text-on-primary font-title-sm text-title-sm rounded-lg shadow-md hover:bg-primary-container active:scale-[0.99] transition-all flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed" id="submitBtn" type="submit">
                <span id="submitBtnLabel">Create Account</span>
                <span class="material-symbols-outlined text-lg" id="submitBtnIcon">arrow_forward</span>
              </button>
              <div class="flex items-center justify-center gap-2 pt-2">
                <span class="font-body-md text-body-md text-on-surface-variant">Already have an account?</span>
                <a class="font-title-sm text-title-sm text-primary hover:underline flex items-center gap-0.5" href="#/login">
                  <span>Login</span>
                  <span class="material-symbols-outlined text-base">login</span>
                </a>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;

  wireUp(container);
}

function wireUp(container) {
  const form = container.querySelector('#registerForm');
  const fullName = container.querySelector('#fullName');
  const age = container.querySelector('#age');
  const email = container.querySelector('#email');
  const password = container.querySelector('#password');
  const confirmPassword = container.querySelector('#confirmPassword');
  const togglePassword = container.querySelector('#togglePassword');
  const goalGroup = container.querySelector('#goalGroup');
  const selectedGoal = container.querySelector('#selectedGoal');
  const experienceGroup = container.querySelector('#experienceGroup');
  const selectedExperience = container.querySelector('#selectedExperience');
  const submitBtn = container.querySelector('#submitBtn');
  const submitBtnLabel = container.querySelector('#submitBtnLabel');
  const submitBtnIcon = container.querySelector('#submitBtnIcon');
  const statusAlert = container.querySelector('#statusAlert');
  const statusIcon = container.querySelector('#statusIcon');
  const statusMsg = container.querySelector('#statusMsg');

  togglePassword.addEventListener('click', () => {
    password.type = password.type === 'password' ? 'text' : 'password';
  });

  goalGroup.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-goal]');
    if (!btn) return;
    selectedGoal.value = btn.getAttribute('data-goal');
    render(container);
  });

  experienceGroup.addEventListener('click', (e) => {
    const card = e.target.closest('[data-experience]');
    if (!card) return;
    selectedExperience.value = card.getAttribute('data-experience');
    render(container);
  });

  function showAlert(kind, message) {
    const bg = kind === 'error' ? 'bg-error-container' : 'bg-surface-container-high';
    const textColor = kind === 'error' ? 'text-on-error-container' : 'text-on-surface';
    statusAlert.className = `mb-5 p-3 rounded-lg ${bg} ${textColor} block transition-all`;
    statusIcon.className = `material-symbols-outlined text-xl mt-0.5 ${kind === 'error' ? 'text-error' : 'text-primary'}`;
    statusIcon.textContent = kind === 'error' ? 'error' : 'info';
    statusMsg.textContent = message;
    statusAlert.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function setLoading(isLoading) {
    submitBtn.disabled = isLoading;
    submitBtnLabel.textContent = isLoading ? 'Creating account...' : 'Create Account';
    submitBtnIcon.className = isLoading
      ? 'w-4 h-4 rounded-full border-2 border-white border-t-transparent animate-spin inline-block'
      : 'material-symbols-outlined text-lg';
    submitBtnIcon.textContent = isLoading ? '' : 'arrow_forward';
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    if (password.value !== confirmPassword.value) {
      showAlert('error', 'Passwords do not match.');
      return;
    }
    if (password.value.length < 6) {
      showAlert('error', 'Password must be at least 6 characters long.');
      return;
    }

    const payload = {
      name: fullName.value.trim(),
      email: email.value.trim(),
      password: password.value,
      fitnessGoal: selectedGoal.value,
      experienceLevel: selectedExperience.value
    };
    if (age.value) {
      payload.age = Number(age.value);
    }

    setLoading(true);
    try {
      await register(payload);
      window.location.hash = '#/dashboard';
    } catch (error) {
      setLoading(false);
      if (error instanceof ApiError) {
        showAlert('error', error.message);
      } else {
        showAlert('error', 'Something went wrong. Please try again.');
      }
    }
  });
}
