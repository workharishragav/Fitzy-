// Minimal app state: the authenticated user + JWT, persisted to
// localStorage so a page refresh doesn't log the person out.
// This is the frontend's equivalent of a "context" — one shared source of
// truth that pages and components read from and update through.

const TOKEN_KEY = 'fitzy_token';
const USER_KEY = 'fitzy_user';

let listeners = [];

export function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}

export function getUser() {
  const raw = localStorage.getItem(USER_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch (e) {
    return null;
  }
}

export function isAuthenticated() {
  return Boolean(getToken());
}

export function setAuth(token, user) {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(user));
  notify();
}

export function setUser(user) {
  localStorage.setItem(USER_KEY, JSON.stringify(user));
  notify();
}

export function clearAuth() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
  notify();
}

/** Subscribe to auth state changes (e.g. header re-rendering on login/logout). */
export function onAuthChange(callback) {
  listeners.push(callback);
  return () => {
    listeners = listeners.filter((l) => l !== callback);
  };
}

function notify() {
  listeners.forEach((callback) => callback());
}
