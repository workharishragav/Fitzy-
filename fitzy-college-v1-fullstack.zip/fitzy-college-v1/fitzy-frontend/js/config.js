// Fitzy frontend runtime config.
// Change apiBaseUrl if your backend isn't running on the default port,
// or if you deploy the backend somewhere other than localhost.
window.FITZY_CONFIG = {
  apiBaseUrl: 'http://localhost:5000'
};
