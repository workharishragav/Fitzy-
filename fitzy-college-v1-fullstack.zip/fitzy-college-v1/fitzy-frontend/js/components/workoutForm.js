import { CATEGORIES } from '../utils/constants.js';
import { toDateInputValue, formatDate } from '../utils/format.js';
import { escapeHtml } from '../utils/dom.js';
import { ApiError } from '../services/apiClient.js';

/**
 * @param {HTMLElement} container
 * @param {{
 *   heading: string,
 *   subheading: string,
 *   submitLabel: string,
 *   initialData?: {workoutName?: string, category?: string, duration?: number, caloriesBurned?: number, workoutDate?: string},
 *   onSubmit: (payload: object) => Promise<void>,
 *   onDelete?: () => Promise<void>
 * }} opts
 */
export function renderWorkoutForm(container, opts) {
  const data = opts.initialData || {};
  const defaultCategory = data.category || 'Cardio';
  const defaultDate = data.workoutDate ? toDateInputValue(data.workoutDate) : toDateInputValue(new Date());

  const categoryButtons = CATEGORIES.map((cat) => {
    const selected = cat.value === defaultCategory;
    return `
      <button type="button" data-category="${escapeHtml(cat.value)}" aria-checked="${selected}" role="radio"
        class="category-btn flex flex-col items-center justify-center p-3 rounded-xl transition-all cursor-pointer ${selected ? 'bg-primary text-on-primary shadow-sm' : 'bg-surface-container text-on-surface-variant hover:bg-surface-container-high hover:text-on-surface'}">
        <span class="material-symbols-outlined text-[24px] mb-1">${cat.icon}</span>
        <span class="font-label-sm text-label-sm">${escapeHtml(cat.value)}</span>
      </button>
    `;
  }).join('');

  container.innerHTML = `
    <div class="w-full max-w-7xl mx-auto px-margin-mobile md:px-margin py-space-lg md:py-space-xl">
      <div class="flex flex-col md:flex-row md:items-end justify-between gap-space-sm mb-space-lg">
        <div>
          <h1 class="font-headline-lg text-headline-lg text-on-surface tracking-tight">${escapeHtml(opts.heading)}</h1>
          <p class="font-body-md text-body-md text-on-surface-variant mt-1">${escapeHtml(opts.subheading)}</p>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-space-lg items-start">
        <div class="lg:col-span-8 flex flex-col gap-space-md">
          <div id="formErrorArea"></div>
          <form class="bg-surface-container-lowest rounded-2xl shadow-md p-space-md md:p-space-xl flex flex-col gap-space-lg" id="workoutForm">
            <div class="flex flex-col gap-1.5">
              <label class="font-label-md text-label-md text-on-surface flex items-center gap-1.5" for="workoutName">
                <span>Workout Name</span><span class="text-error font-body-sm">*</span>
              </label>
              <div class="relative flex items-center">
                <span class="absolute left-3.5 text-outline pointer-events-none material-symbols-outlined text-[20px]">edit_note</span>
                <input class="w-full h-12 pl-11 pr-4 rounded-lg bg-surface-container-low text-on-surface font-body-md text-body-md focus:bg-surface-container-lowest focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all placeholder:text-outline" id="workoutName" placeholder="e.g. Morning Run" required type="text" value="${escapeHtml(data.workoutName || '')}"/>
              </div>
            </div>

            <div class="flex flex-col gap-2">
              <label class="font-label-md text-label-md text-on-surface">Category</label>
              <div aria-label="Workout Category" class="grid grid-cols-2 sm:grid-cols-4 gap-2" id="categorySelector" role="radiogroup">
                ${categoryButtons}
              </div>
              <input type="hidden" id="selectedCategory" value="${escapeHtml(defaultCategory)}"/>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-space-md">
              <div class="flex flex-col gap-1.5">
                <label class="font-label-md text-label-md text-on-surface" for="durationInput">Duration</label>
                <div class="relative flex items-center">
                  <span class="absolute left-3.5 text-outline pointer-events-none material-symbols-outlined text-[20px]">timer</span>
                  <input class="w-full h-12 pl-11 pr-14 rounded-lg bg-surface-container-low text-on-surface font-title-sm text-title-sm focus:bg-surface-container-lowest focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all font-semibold" id="durationInput" max="1440" min="1" required type="number" value="${data.duration ?? ''}"/>
                  <span class="absolute right-3.5 text-outline font-label-md text-label-md font-semibold pointer-events-none">mins</span>
                </div>
              </div>
              <div class="flex flex-col gap-1.5">
                <label class="font-label-md text-label-md text-on-surface" for="caloriesInput">Calories Burned</label>
                <div class="relative flex items-center">
                  <span class="absolute left-3.5 text-outline pointer-events-none material-symbols-outlined text-[20px]">local_fire_department</span>
                  <input class="w-full h-12 pl-11 pr-14 rounded-lg bg-surface-container-low text-on-surface font-title-sm text-title-sm focus:bg-surface-container-lowest focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all font-semibold" id="caloriesInput" min="0" required type="number" value="${data.caloriesBurned ?? ''}"/>
                  <span class="absolute right-3.5 text-outline font-label-md text-label-md font-semibold pointer-events-none">kcal</span>
                </div>
              </div>
            </div>

            <div class="flex flex-col gap-1.5">
              <label class="font-label-md text-label-md text-on-surface" for="dateInput">Workout Date</label>
              <div class="relative flex items-center">
                <span class="absolute left-3.5 text-outline pointer-events-none material-symbols-outlined text-[20px]">calendar_today</span>
                <input class="w-full h-12 pl-11 pr-4 rounded-lg bg-surface-container-low text-on-surface font-body-md text-body-md focus:bg-surface-container-lowest focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all cursor-pointer" id="dateInput" required type="date" value="${defaultDate}"/>
              </div>
            </div>

            <div class="flex flex-col-reverse sm:flex-row items-center justify-end gap-space-sm pt-space-xs">
              <button class="w-full sm:w-auto px-space-lg h-12 rounded-lg bg-surface-container text-on-surface hover:bg-surface-container-high transition-colors font-label-md text-label-md font-semibold flex items-center justify-center" id="cancelBtn" type="button">
                Cancel
              </button>
              <button class="w-full sm:w-auto px-space-xl h-12 rounded-lg bg-primary text-on-primary hover:opacity-95 active:scale-[0.99] transition-all shadow-md font-label-md text-label-md font-semibold flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed" id="submitBtn" type="submit">
                <span class="material-symbols-outlined text-[20px]" id="submitBtnIcon">check</span>
                <span id="submitBtnLabel">${escapeHtml(opts.submitLabel)}</span>
              </button>
            </div>
          </form>
        </div>

        <div class="lg:col-span-4 flex flex-col gap-space-md">
          <div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm flex flex-col gap-space-md">
            <span class="font-label-sm text-label-sm text-outline tracking-wider uppercase">Live Preview</span>
            <div class="flex items-center gap-space-sm">
              <div class="w-12 h-12 rounded-xl bg-primary-fixed-dim text-on-primary-fixed flex items-center justify-center shrink-0">
                <span class="material-symbols-outlined text-[26px]" id="previewIcon">${CATEGORIES.find((c) => c.value === defaultCategory)?.icon || 'fitness_center'}</span>
              </div>
              <div class="min-w-0 flex-1">
                <h3 class="font-title-sm text-title-sm text-on-surface truncate font-bold" id="previewTitle">${escapeHtml(data.workoutName || 'Your workout')}</h3>
                <p class="font-body-sm text-body-sm text-on-surface-variant" id="previewMeta">${escapeHtml(defaultCategory)} • ${formatDate(defaultDate)}</p>
              </div>
            </div>
            <div class="p-space-md rounded-xl bg-surface-container-low flex items-center justify-between">
              <div class="flex flex-col">
                <span class="font-label-sm text-label-sm text-outline">ESTIMATE</span>
                <span class="font-metric-val text-metric-val text-primary tracking-tight" id="previewCal">${data.caloriesBurned || 0} <span class="font-label-md text-label-md text-on-surface-variant font-normal">kcal</span></span>
                <span class="font-body-sm text-body-sm text-on-surface-variant" id="previewDur">${data.duration || 0} minutes</span>
              </div>
            </div>
          </div>
          ${opts.onDelete ? `
          <button type="button" id="deleteFromFormBtn" class="inline-flex items-center justify-center gap-space-xs px-space-md py-3 bg-error-container text-on-error-container font-label-md text-label-md rounded-xl shadow-sm hover:opacity-90 transition-all">
            <span class="material-symbols-outlined text-[18px]">delete</span>
            <span>Delete Workout</span>
          </button>` : ''}
        </div>
      </div>
    </div>
  `;

  wireUp(container, opts);
}

function wireUp(container, opts) {
  const form = container.querySelector('#workoutForm');
  const nameInput = container.querySelector('#workoutName');
  const categorySelector = container.querySelector('#categorySelector');
  const selectedCategory = container.querySelector('#selectedCategory');
  const durationInput = container.querySelector('#durationInput');
  const caloriesInput = container.querySelector('#caloriesInput');
  const dateInput = container.querySelector('#dateInput');
  const cancelBtn = container.querySelector('#cancelBtn');
  const submitBtn = container.querySelector('#submitBtn');
  const submitBtnLabel = container.querySelector('#submitBtnLabel');
  const submitBtnIcon = container.querySelector('#submitBtnIcon');
  const formErrorArea = container.querySelector('#formErrorArea');
  const previewIcon = container.querySelector('#previewIcon');
  const previewTitle = container.querySelector('#previewTitle');
  const previewMeta = container.querySelector('#previewMeta');
  const previewCal = container.querySelector('#previewCal');
  const previewDur = container.querySelector('#previewDur');

  function updatePreview() {
    const cat = CATEGORIES.find((c) => c.value === selectedCategory.value);
    previewIcon.textContent = cat ? cat.icon : 'fitness_center';
    previewTitle.textContent = nameInput.value.trim() || 'Your workout';
    previewMeta.textContent = `${selectedCategory.value} • ${formatDate(dateInput.value)}`;
    previewCal.innerHTML = `${caloriesInput.value || 0} <span class="font-label-md text-label-md text-on-surface-variant font-normal">kcal</span>`;
    previewDur.textContent = `${durationInput.value || 0} minutes`;
  }

  [nameInput, durationInput, caloriesInput, dateInput].forEach((el) => {
    el.addEventListener('input', updatePreview);
  });

  categorySelector.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-category]');
    if (!btn) return;
    selectedCategory.value = btn.getAttribute('data-category');
    categorySelector.querySelectorAll('.category-btn').forEach((b) => {
      const isSelected = b === btn;
      b.className = `category-btn flex flex-col items-center justify-center p-3 rounded-xl transition-all cursor-pointer ${isSelected ? 'bg-primary text-on-primary shadow-sm' : 'bg-surface-container text-on-surface-variant hover:bg-surface-container-high hover:text-on-surface'}`;
      b.setAttribute('aria-checked', String(isSelected));
    });
    updatePreview();
  });

  cancelBtn.addEventListener('click', () => {
    window.history.back();
  });

  if (opts.onDelete) {
    container.querySelector('#deleteFromFormBtn')?.addEventListener('click', () => opts.onDelete());
  }

  function showFormError(message) {
    formErrorArea.innerHTML = `
      <div class="p-space-md rounded-xl bg-error-container text-on-error-container flex items-start gap-space-sm">
        <span class="material-symbols-outlined text-[20px] shrink-0">error</span>
        <p class="font-body-sm text-body-sm">${escapeHtml(message)}</p>
      </div>
    `;
    formErrorArea.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function setLoading(isLoading) {
    submitBtn.disabled = isLoading;
    submitBtnIcon.className = isLoading
      ? 'w-4 h-4 rounded-full border-2 border-white border-t-transparent animate-spin inline-block'
      : 'material-symbols-outlined text-[20px]';
    submitBtnIcon.textContent = isLoading ? '' : 'check';
    submitBtnLabel.textContent = isLoading ? 'Saving...' : opts.submitLabel;
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    formErrorArea.innerHTML = '';

    const name = nameInput.value.trim();
    const duration = Number(durationInput.value);
    const calories = Number(caloriesInput.value);

    if (!name) {
      showFormError('Workout name is required.');
      return;
    }
    if (!durationInput.value || !Number.isFinite(duration) || duration <= 0) {
      showFormError('Duration must be a positive number of minutes.');
      return;
    }
    if (!caloriesInput.value || !Number.isFinite(calories) || calories < 0) {
      showFormError('Calories burned must be zero or a positive number.');
      return;
    }
    if (!dateInput.value) {
      showFormError('Workout date is required.');
      return;
    }

    const payload = {
      workoutName: name,
      category: selectedCategory.value,
      duration,
      caloriesBurned: calories,
      workoutDate: dateInput.value
    };

    setLoading(true);
    try {
      await opts.onSubmit(payload);
    } catch (error) {
      setLoading(false);
      const message = error instanceof ApiError ? error.message : 'Something went wrong. Please try again.';
      showFormError(message);
    }
  });

  updatePreview();
}
