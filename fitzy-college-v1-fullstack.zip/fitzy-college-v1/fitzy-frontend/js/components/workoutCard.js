import { categoryMeta } from '../utils/constants.js';
import { formatDate, formatNumber } from '../utils/format.js';
import { escapeHtml } from '../utils/dom.js';

/**
 * Renders one workout as a clickable row card (used in Dashboard's
 * recent-workouts list and the full Workout History list).
 */
export function renderWorkoutCard(workout) {
  const meta = categoryMeta(workout.category);
  const iconBg = `bg-${meta.color}-container/10`;
  const iconColor = `text-${meta.color}`;
  const badgeBg = `bg-${meta.color}-fixed/40`;
  const badgeText = `text-on-${meta.color}-fixed`;

  return `
    <article class="workout-card group bg-surface-container-lowest rounded-2xl p-space-md md:p-space-lg shadow-sm hover:shadow-md transition-all duration-300 flex flex-col md:flex-row md:items-center justify-between gap-space-md cursor-pointer" data-workout-id="${escapeHtml(workout._id)}">
      <div class="flex items-start md:items-center gap-space-md min-w-0">
        <div class="w-14 h-14 rounded-2xl ${iconBg} flex-shrink-0 flex items-center justify-center ${iconColor} group-hover:scale-105 transition-transform">
          <span class="material-symbols-outlined text-[28px]">${meta.icon}</span>
        </div>
        <div class="flex flex-col min-w-0">
          <div class="flex flex-wrap items-center gap-2 mb-1">
            <span class="h-6 px-2.5 rounded-full ${badgeBg} ${badgeText} font-label-sm text-label-sm uppercase tracking-wider flex items-center gap-1 font-bold">
              <span class="w-1.5 h-1.5 rounded-full bg-${meta.color}"></span>
              ${escapeHtml(workout.category)}
            </span>
            <span class="font-body-sm text-body-sm text-on-surface-variant font-medium">${formatDate(workout.workoutDate)}</span>
          </div>
          <h2 class="font-headline-md text-headline-md text-on-surface font-bold tracking-tight truncate">${escapeHtml(workout.workoutName)}</h2>
        </div>
      </div>
      <div class="flex items-center justify-between md:justify-end gap-space-lg pt-space-sm md:pt-0 border-t md:border-t-0 border-surface-container">
        <div class="flex items-center gap-6">
          <div class="flex flex-col items-start md:items-end">
            <span class="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant font-semibold">Duration</span>
            <span class="font-title-sm text-title-sm font-bold text-on-surface">${formatNumber(workout.duration)} mins</span>
          </div>
          <div class="flex flex-col items-start md:items-end">
            <span class="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant font-semibold">Calories</span>
            <span class="font-title-sm text-title-sm font-bold text-primary">${formatNumber(workout.caloriesBurned)} kcal</span>
          </div>
        </div>
        <button type="button" aria-label="View workout details" class="workout-card-chevron w-10 h-10 rounded-xl bg-surface-container-low hover:bg-primary hover:text-on-primary text-on-surface-variant flex items-center justify-center transition-colors" data-workout-id="${escapeHtml(workout._id)}">
          <span class="material-symbols-outlined text-[20px]">chevron_right</span>
        </button>
      </div>
    </article>
  `;
}
