import { escapeHtml } from '../utils/dom.js';

/**
 * Shows a confirmation modal (used for destructive actions like deleting
 * a workout). Returns a Promise<boolean> — resolves true if confirmed.
 * @param {{title: string, message: string, confirmLabel?: string, danger?: boolean}} opts
 */
export function confirmDialog({ title, message, confirmLabel = 'Confirm', danger = true }) {
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.className =
      'fixed inset-0 z-50 bg-inverse-surface/60 backdrop-blur-sm flex items-center justify-center p-space-md';

    const iconWrapClasses = danger ? 'bg-error-container text-error' : 'bg-primary-fixed text-on-primary-fixed';
    const confirmBtnClasses = danger
      ? 'bg-error text-on-error hover:bg-error/90'
      : 'bg-primary text-on-primary hover:bg-primary-container';

    overlay.innerHTML = `
      <div class="fitzy-modal-pop bg-surface-container-lowest max-w-md w-full rounded-2xl shadow-2xl p-space-lg relative flex flex-col gap-space-md">
        <div class="flex items-center gap-space-md">
          <div class="w-12 h-12 rounded-xl ${iconWrapClasses} flex items-center justify-center shrink-0">
            <span class="material-symbols-outlined text-[28px]">${danger ? 'warning' : 'help'}</span>
          </div>
          <div class="min-w-0">
            <h2 class="font-headline-md text-headline-md text-on-surface tracking-tight">${escapeHtml(title)}</h2>
          </div>
        </div>
        <p class="font-body-md text-body-md text-on-surface-variant leading-relaxed">${escapeHtml(message)}</p>
        <div class="flex flex-col-reverse sm:flex-row items-center justify-end gap-space-sm pt-space-xs">
          <button type="button" data-action="cancel" class="w-full sm:w-auto px-space-lg py-3 bg-surface-container text-on-surface font-label-md text-label-md rounded-lg shadow-sm hover:bg-surface-container-high transition-colors">Cancel</button>
          <button type="button" data-action="confirm" class="w-full sm:w-auto px-space-lg py-3 ${confirmBtnClasses} font-label-md text-label-md rounded-lg shadow-md transition-all flex items-center justify-center gap-space-xs">${escapeHtml(confirmLabel)}</button>
        </div>
        <button type="button" data-action="cancel" aria-label="Close dialog" class="absolute top-4 right-4 text-on-surface-variant hover:text-on-surface p-1 rounded-full hover:bg-surface-container transition-colors">
          <span class="material-symbols-outlined text-[20px]">close</span>
        </button>
      </div>
    `;

    function close(result) {
      document.removeEventListener('keydown', onKeydown);
      overlay.remove();
      resolve(result);
    }

    function onKeydown(e) {
      if (e.key === 'Escape') close(false);
    }

    overlay.addEventListener('click', (e) => {
      const action = e.target.closest('[data-action]')?.getAttribute('data-action');
      if (action === 'cancel') close(false);
      if (action === 'confirm') close(true);
      if (e.target === overlay) close(false);
    });
    document.addEventListener('keydown', onKeydown);

    document.body.appendChild(overlay);
  });
}
