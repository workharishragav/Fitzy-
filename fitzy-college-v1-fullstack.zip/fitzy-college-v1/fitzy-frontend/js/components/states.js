import { escapeHtml } from '../utils/dom.js';

export function renderLoading(message = 'Loading...') {
  return `
    <div class="w-full flex flex-col items-center justify-center py-space-xl gap-space-md text-center">
      <div class="w-12 h-12 rounded-full border-4 border-surface-container border-t-primary animate-spin"></div>
      <p class="font-body-md text-body-md text-on-surface-variant">${escapeHtml(message)}</p>
    </div>
  `;
}

/**
 * @param {{icon?: string, title: string, message: string, actionLabel?: string, actionHref?: string}} opts
 */
export function renderEmptyState({ icon = 'assignment_add', title, message, actionLabel, actionHref }) {
  const action = actionLabel && actionHref
    ? `<a href="${actionHref}" class="h-12 px-space-lg bg-primary hover:bg-primary-container text-on-primary font-label-md text-label-md rounded-xl shadow-md flex items-center justify-center gap-2 transition-all active:scale-[0.98]">
         <span class="material-symbols-outlined text-[20px]">add_circle</span>
         <span>${escapeHtml(actionLabel)}</span>
       </a>`
    : '';

  return `
    <div class="flex flex-col items-center justify-center py-space-xl px-space-lg bg-surface-container-lowest rounded-3xl shadow-sm text-center">
      <div class="w-24 h-24 rounded-3xl bg-primary-container/10 flex items-center justify-center text-primary shadow-inner mb-space-md">
        <span class="material-symbols-outlined text-[48px]">${icon}</span>
      </div>
      <h3 class="font-headline-lg text-headline-lg text-on-surface tracking-tight max-w-md">${escapeHtml(title)}</h3>
      <p class="font-body-md text-body-md text-on-surface-variant max-w-md mt-space-xs mb-space-lg">${escapeHtml(message)}</p>
      ${action}
    </div>
  `;
}

/**
 * @param {{title?: string, message: string, retryId?: string}} opts
 * retryId: if provided, renders a "Try again" button with that element id
 * so the calling page can attach its own click handler after insertion.
 */
export function renderErrorBanner({ title = 'Something went wrong', message, retryId }) {
  const retryBtn = retryId
    ? `<button type="button" id="${retryId}" class="px-space-md py-2 bg-error text-on-error font-label-md text-label-md rounded-xl shadow hover:bg-error/90 transition-all flex items-center gap-2 whitespace-nowrap">
         <span class="material-symbols-outlined text-[18px]">refresh</span> Try again
       </button>`
    : '';

  return `
    <div class="p-space-md rounded-2xl bg-error-container text-on-error-container shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-space-md">
      <div class="flex items-center gap-space-sm">
        <div class="p-2 bg-error text-on-error rounded-xl flex items-center justify-center shrink-0">
          <span class="material-symbols-outlined text-[24px]">cloud_off</span>
        </div>
        <div>
          <h4 class="font-title-sm text-title-sm text-on-error-container">${escapeHtml(title)}</h4>
          <p class="font-body-sm text-body-sm text-on-error-container/80">${escapeHtml(message)}</p>
        </div>
      </div>
      ${retryBtn}
    </div>
  `;
}
