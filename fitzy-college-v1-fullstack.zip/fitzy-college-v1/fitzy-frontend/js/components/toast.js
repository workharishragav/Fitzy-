import { escapeHtml } from '../utils/dom.js';

let toastEl = null;
let hideTimeout = null;

const ICONS = {
  info: 'info',
  success: 'task_alt',
  error: 'error'
};

function ensureToastEl() {
  if (toastEl) return toastEl;
  toastEl = document.createElement('div');
  toastEl.id = 'fitzy-toast';
  toastEl.className =
    'fixed bottom-20 md:bottom-8 right-1/2 translate-x-1/2 md:translate-x-0 md:right-8 px-space-md py-space-sm rounded-xl shadow-xl flex items-center gap-2 pointer-events-none opacity-0 transition-opacity duration-300 z-[60]';
  document.body.appendChild(toastEl);
  return toastEl;
}

/**
 * @param {string} message
 * @param {'info'|'success'|'error'} type
 */
export function showToast(message, type = 'info') {
  const el = ensureToastEl();
  const colorClasses =
    type === 'error'
      ? 'bg-error text-on-error'
      : type === 'success'
      ? 'bg-primary text-on-primary'
      : 'bg-inverse-surface text-inverse-on-surface';

  el.className = `fixed bottom-20 md:bottom-8 right-1/2 translate-x-1/2 md:translate-x-0 md:right-8 px-space-md py-space-sm rounded-xl shadow-xl flex items-center gap-2 transition-opacity duration-300 z-[60] opacity-100 ${colorClasses}`;
  el.innerHTML = `
    <span class="material-symbols-outlined text-[20px]">${ICONS[type] || ICONS.info}</span>
    <span class="font-label-md text-label-md">${escapeHtml(message)}</span>
  `;

  if (hideTimeout) clearTimeout(hideTimeout);
  hideTimeout = setTimeout(() => {
    el.classList.remove('opacity-100');
    el.classList.add('opacity-0');
  }, 3200);
}
