import { getUser } from '../state/store.js';
import { escapeHtml } from '../utils/dom.js';

const NAV_LINKS = [
  { route: 'dashboard', label: 'Dashboard' },
  { route: 'workouts', label: 'Workouts' },
  { route: 'ai-recommendation', label: 'AI Coach' },
  { route: 'profile', label: 'Profile' }
];

function initials(name) {
  if (!name) return 'FZ';
  const parts = name.trim().split(/\s+/);
  const first = parts[0]?.[0] || '';
  const last = parts.length > 1 ? parts[parts.length - 1][0] : '';
  return (first + last).toUpperCase() || 'FZ';
}

/**
 * @param {string} activeRoute - which nav item to highlight (dashboard/workouts/ai-recommendation/ai-insights/profile)
 */
export function renderHeader(activeRoute) {
  const user = getUser();
  const name = user?.name || 'Athlete';
  const goal = user?.fitnessGoal || 'Getting started';

  const links = NAV_LINKS.map((link) => {
    const isActive = activeRoute === link.route;
    const activeClasses = 'bg-primary-container text-on-primary-container font-label-md text-label-md rounded-lg';
    const inactiveClasses = 'font-label-md text-label-md text-on-surface-variant hover:text-on-surface transition-colors';
    return `<a href="#/${link.route}" class="px-space-md py-space-xs transition-colors ${isActive ? activeClasses : inactiveClasses}" ${isActive ? 'aria-current="page"' : ''}>${escapeHtml(link.label)}</a>`;
  }).join('');

  return `
    <div class="h-16 max-w-7xl mx-auto px-margin flex items-center justify-between">
      <a href="#/dashboard" class="flex items-center gap-space-sm">
        <div class="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-on-primary">
          <span class="material-symbols-outlined text-lg" style="font-variation-settings: 'FILL' 1;">bolt</span>
        </div>
        <span class="font-headline-md text-headline-md tracking-tight text-on-surface">Fitzy<span class="text-primary ml-1">AI</span></span>
      </a>
      <nav class="hidden md:flex items-center gap-space-xs bg-surface-container-low p-1 rounded-xl">
        ${links}
      </nav>
      <div class="flex items-center gap-space-md">
        <div class="hidden sm:flex flex-col text-right">
          <span class="font-label-md text-label-md text-on-surface">${escapeHtml(name)}</span>
          <span class="font-label-sm text-label-sm text-primary">${escapeHtml(goal)}</span>
        </div>
        <a href="#/profile" class="relative inline-flex items-center justify-center w-9 h-9 rounded-full bg-primary-container text-on-primary-container font-label-sm text-label-sm font-bold hover:ring-2 hover:ring-primary/20 transition-all" aria-label="Profile">
          ${escapeHtml(initials(name))}
        </a>
      </div>
    </div>
  `;
}
