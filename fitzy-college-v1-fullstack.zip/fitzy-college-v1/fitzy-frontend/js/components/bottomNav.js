const NAV_ITEMS = [
  { route: 'dashboard', label: 'Home', icon: 'dashboard' },
  { route: 'workouts', label: 'Workouts', icon: 'fitness_center' },
  { route: 'ai-recommendation', label: 'AI Coach', icon: 'neurology' },
  { route: 'profile', label: 'Profile', icon: 'person' }
];

export function renderBottomNav(activeRoute) {
  const items = NAV_ITEMS.map((item) => {
    const isActive = activeRoute === item.route;
    const activeClasses = 'bg-primary text-on-primary rounded-xl';
    const inactiveClasses = 'text-on-surface-variant hover:text-on-surface';
    return `
      <a href="#/${item.route}" class="flex flex-col items-center justify-center py-2 px-3 transition-all ${isActive ? activeClasses : inactiveClasses}" ${isActive ? 'aria-current="page"' : ''}>
        <span class="material-symbols-outlined text-[22px]">${item.icon}</span>
        <span class="font-label-sm text-label-sm mt-0.5">${item.label}</span>
      </a>
    `;
  }).join('');

  return `
    <nav class="pointer-events-auto max-w-md mx-auto bg-surface-container-lowest/90 backdrop-blur-xl shadow-[0_4px_20px_rgba(0,0,0,0.08)] rounded-2xl p-space-xs flex items-center justify-around">
      ${items}
    </nav>
  `;
}
