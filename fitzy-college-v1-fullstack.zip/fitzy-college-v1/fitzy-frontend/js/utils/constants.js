// These lists must stay in sync with the backend's Mongoose enums
// (server/models/Workout.js category, server/models/User.js fitnessGoal /
// experienceLevel) — the backend is the source of truth for what values
// are valid; this file only adds icon/subtitle presentation on top.

export const CATEGORIES = [
  { value: 'Cardio', icon: 'directions_run', color: 'primary' },
  { value: 'Strength', icon: 'fitness_center', color: 'secondary' },
  { value: 'Flexibility', icon: 'accessibility_new', color: 'tertiary' },
  { value: 'HIIT', icon: 'bolt', color: 'primary' },
  { value: 'Yoga', icon: 'self_improvement', color: 'tertiary' },
  { value: 'Sports', icon: 'sports_basketball', color: 'secondary' },
  { value: 'Other', icon: 'more_horiz', color: 'secondary' }
];

export const FITNESS_GOALS = [
  { value: 'Weight Loss', icon: 'speed', subtitle: 'Fat burn & deficit' },
  { value: 'Muscle Gain', icon: 'fitness_center', subtitle: 'Hypertrophy & load' },
  { value: 'Endurance', icon: 'directions_run', subtitle: 'Cardio stamina' },
  { value: 'Flexibility', icon: 'self_improvement', subtitle: 'Mobility & range' },
  { value: 'General Fitness', icon: 'favorite', subtitle: 'Vitality & posture' }
];

export const EXPERIENCE_LEVELS = [
  { value: 'Beginner', subtitle: 'Under 6 months of training experience' },
  { value: 'Intermediate', subtitle: '1–3 years of consistent training' },
  { value: 'Advanced', subtitle: '3+ years of dedicated training' }
];

export function categoryMeta(value) {
  return CATEGORIES.find((c) => c.value.toLowerCase() === String(value).toLowerCase()) || CATEGORIES[CATEGORIES.length - 1];
}
