// Every dynamic string (workout names, user name/email, AI-generated
// text) MUST go through escapeHtml before being interpolated into an
// innerHTML template — this is a vanilla-JS app with no framework doing
// that escaping for us automatically.

export function escapeHtml(value) {
  if (value === null || value === undefined) return '';
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function qs(selector, root = document) {
  return root.querySelector(selector);
}

export function qsa(selector, root = document) {
  return Array.from(root.querySelectorAll(selector));
}
