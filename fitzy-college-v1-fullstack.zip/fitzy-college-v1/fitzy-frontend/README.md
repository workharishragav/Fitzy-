# Fitzy — College V1 Frontend

A frontend for the Fitzy College V1 backend: authentication, workout
tracking (CRUD + search), and AI-powered workout recommendations /
fitness insights.

## Tech stack

Vanilla HTML/CSS/JavaScript — ES modules, hash-based routing, no build
step, no framework. Styling is Tailwind CSS via the same CDN + design
tokens (colors, spacing, type scale) used in the original Fitzy reference
designs, so the visual language carries through exactly.

**Why not React/Vite?** The reference designs themselves are plain
HTML + Tailwind CDN + vanilla JS — this continues that same technology
rather than introducing a new one, and it means zero new dependencies and
no build step for you to manage. `package.json` only declares
`"type": "module"` (so the browser and any tooling treat the `.js` files
as ES modules) — there's nothing to `npm install`.

## Project structure

```
fitzy-frontend/
├── index.html              App shell: header/main/bottom-nav/footer mount points,
│                            Tailwind config (matches the reference design system)
├── css/
│   └── styles.css          Small additions on top of Tailwind CDN utilities
├── js/
│   ├── config.js            Runtime config — API_BASE_URL (edit this first!)
│   ├── app.js                Router: hash-based routes, auth guard, shell toggling
│   ├── state/
│   │   └── store.js          Auth token/user persistence (localStorage) + pub-sub
│   ├── services/              All backend calls live here — pages never call fetch() directly
│   │   ├── apiClient.js        Centralized fetch wrapper, attaches JWT, normalizes errors
│   │   ├── authService.js      register / login / profile / logout
│   │   ├── workoutService.js   Workout CRUD + search
│   │   └── aiService.js        AI recommendation / insights
│   ├── components/            Reusable UI pieces
│   │   ├── header.js, bottomNav.js    App shell nav
│   │   ├── workoutCard.js             Workout list row
│   │   ├── workoutForm.js             Shared Add/Edit workout form
│   │   ├── confirmModal.js            Delete confirmation dialog
│   │   ├── toast.js                   Success/error toast
│   │   └── states.js                  Loading / empty / error state blocks
│   ├── pages/                 One module per screen, each exports render(container, params)
│   │   ├── login.js, register.js
│   │   ├── dashboard.js
│   │   ├── workoutHistory.js, addWorkout.js, editWorkout.js, workoutDetails.js
│   │   ├── aiRecommendation.js, aiInsights.js
│   │   └── profile.js
│   └── utils/
│       ├── constants.js       Category/goal/experience lists — MUST stay in sync with the backend's Mongoose enums
│       ├── dom.js              escapeHtml() — used everywhere dynamic content is rendered
│       └── format.js           Date/number formatting
└── package.json
```

## Setup

1. **Point it at your backend.** Open `js/config.js` and set `apiBaseUrl`
   if your Fitzy backend isn't running on `http://localhost:5000`.

2. **Serve it with a static server.** This app uses ES modules
   (`import`/`export`), which browsers block over `file://` due to CORS —
   you can't just double-click `index.html`. Use any of:
   ```
   npx serve .
   # or
   python3 -m http.server 5173
   # or the VS Code "Live Server" extension
   ```
   Then open the printed URL (e.g. `http://localhost:5173`).

3. **Run the backend too.** This frontend has zero mock data — every
   screen calls the real API. Start the Fitzy backend (`npm run dev` in
   `server/`) with a working `MONGO_URI` and `GEMINI_API_KEY`, or nothing
   will load.

4. **CORS:** the backend's `cors()` is already open to all origins by
   default (see the backend's Phase 13 security notes), so no backend
   change is needed for this to reach it locally.

## How routing works

Hash-based (`#/dashboard`, `#/workouts/:id`, etc.) — no server-side
routing needed, so any static file host works. `js/app.js` holds the
route table, redirects unauthenticated users to `#/login` for protected
routes, and redirects logged-in users away from `#/login`/`#/register`.

## Design decisions worth knowing about

These were made by comparing the reference designs against what the
College V1 backend actually provides, per the "don't mock the backend"
rule:

- **Branding:** the references say "FitTrack AI" (an earlier working
  title); this build uses **Fitzy**, the actual product name, with the
  same logo-mark treatment.
- **7 workout categories, not 6:** the reference's category picker shows
  6; the backend's `Workout` schema enum has 7 (`Cardio, Strength,
  Flexibility, HIIT, Yoga, Sports, Other`). Added **HIIT**.
- **5 fitness goals, not 4:** same reasoning — added **Flexibility** to
  match the `User` schema's `fitnessGoal` enum.
- **No stock photography or fabricated telemetry.** The references use
  placeholder photos and invented stats the backend has no field for
  (heart rate, VO2 max, RPE, sleep, exercise-by-exercise sets/reps,
  "collegiate percentile rank", etc.). Those are dropped; the same card
  *shapes* and visual rhythm are kept, filled only with real fields
  (`workoutName, category, duration, caloriesBurned, workoutDate`, the
  user's profile fields, and the AI endpoints' actual JSON response).
- **No "Edit Profile."** The backend only exposes `GET
  /api/auth/profile` — there's no update endpoint — so the Profile page
  is read-only plus Logout, rather than shipping an edit form that
  silently does nothing.
- **AI Insights auto-computes its inputs.** Per the spec ("use the
  user's workout data"), `totalWorkouts` / `averageWorkoutDuration` /
  `totalCaloriesBurned` are calculated from the user's real logged
  workouts, not typed in by hand.
- **AI routes are called as the backend built them: JWT-protected**,
  matching the backend's own Phase 11 design choice.

## Verification performed

- `node --check` passed on all 26 `.js` files (this sandbox has no
  browser, so this confirms syntax validity — not a live DOM/network
  test).
- Every relative `import` was resolved programmatically against the
  actual file tree — none broken.
- Swept for leftover "FitTrack" branding, TODOs/placeholders/mock data,
  out-of-scope business features (gym/admin/membership/etc.), and
  hardcoded secrets — all clean.

**Not verified:** an actual browser session against a running backend —
this sandbox has no network access and can't launch a browser. Serve it
locally per the Setup steps above and click through it to confirm the
full flow end-to-end.
