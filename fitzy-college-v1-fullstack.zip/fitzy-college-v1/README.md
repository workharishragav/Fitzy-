# Fitzy — College V1 (Full Stack)

Personalized fitness tracking with AI-powered recommendations. This
archive contains both halves of the College V1 project:

```
fitzy-college-v1/
├── server/            Backend — Node/Express/MongoDB/JWT/Gemini API
│                       See server/README.md for setup, API reference,
│                       and server/postman/ for the Postman collection.
└── fitzy-frontend/    Frontend — vanilla HTML/CSS/JS, ES modules
                        See fitzy-frontend/README.md for setup.
```

## Quick start

1. **Backend first:**
   ```
   cd server
   cp .env.example .env   # fill in MONGO_URI, JWT_SECRET, GEMINI_API_KEY
   npm install
   npm run dev            # runs on http://localhost:5000
   ```

2. **Frontend, in a second terminal:**
   ```
   cd fitzy-frontend
   # js/config.js already points at http://localhost:5000 by default
   npx serve .             # or any static file server
   ```
   Open the printed URL — the frontend talks to the backend over the real
   API the whole way through (no mock data on either side).

Each subfolder's own README has the full details: the backend's covers
every endpoint, the security model, and how to run its Postman
collection; the frontend's covers the project structure and the specific
design decisions made when adapting the reference screens to what the
backend actually provides.
